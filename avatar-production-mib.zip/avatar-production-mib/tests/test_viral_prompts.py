"""tests/test_viral_prompts.py — v1.0.14 prompt builders + chain tests.

Covers:
  1. viral_titles: prompt contains all 8 structures, 15 categories,
     6 audiences, the count (20) and the ranking instruction; parser
     extracts 20 titles and dedups the rank section.
  2. amish_script: prompt contains "Elias Yoder", all 8 section names
     with word counts, the 3 curiosity-loop phrases, the no-bullet-points
     rule; section_word_counts() hits minutes*130 wpm within +-10% for
     5/15/30-min targets.
  3. thumbnail: prompt contains the full locked character spec, the
     40%/60% composition and the 3-word overlay rule; derive_overlay_text
     never exceeds 3 words and is UPPERCASE.
  4. chain: URL -> study metadata -> 20 titles -> top title -> script
     (amish) -> thumbnail prompt, with fakes (no network), ending in a
     real package.run thumbnail-prompt.txt containing the locked spec.
  5. UI wiring (offscreen): Settings script-style selector saves
     "amish"; wizard Title page has the two new buttons; Generate opts
     carry script_style.

Run: MIB_CONFIG_DIR=<tmpdir> QT_QPA_PLATFORM=offscreen python
     tests/test_viral_prompts.py
Also pytest-collectable (plain assert test_* functions).
"""
import os
import sys
import tempfile
from pathlib import Path

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
os.environ["MIB_CONFIG_DIR"] = tempfile.mkdtemp(prefix="mib-viral-")
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from mib.prompts import viral_titles as vt  # noqa: E402
from mib.prompts import amish_script as am  # noqa: E402
from mib.prompts import thumbnail as th  # noqa: E402


# ---------------------------------------------------------------- 1. titles

def test_title_prompt_contents():
    p = vt.build_prompt("Test Channel", "amish gardening")
    assert "20" in p
    for s in vt.STRUCTURES:
        assert s in p, f"missing structure: {s}"
    for c in vt.CATEGORIES:
        assert c in p, f"missing category: {c}"
    for a in vt.AUDIENCES:
        assert a in p, f"missing audience: {a}"
    assert "RANKED TOP 20" in p
    assert "strongest-first" in p or "strongest first" in p


def test_parse_titles():
    lines = []
    for i in range(1, 21):
        lines.append(f"{i}. The $3 Trick That Kills Weeds Forever ({i})")
    lines += ["", "RANKED TOP 20 (strongest first):", ""]
    for i in range(1, 21):
        lines.append(f"{i}. The $3 Trick That Kills Weeds Forever ({i})")
    titles = vt.parse_titles("\n".join(lines))
    assert len(titles) == 20, f"got {len(titles)}"
    assert titles[0].startswith("The $3 Trick")
    block = vt.ranked_block(titles)
    assert block.splitlines()[2].startswith("1. ")
    assert "20. " in block


def test_parse_titles_variants():
    text = "1) Stop Buying Weed Killer\n2: Why the Amish Never Get Weeds\n"
    titles = vt.parse_titles(text)
    assert titles == ["Stop Buying Weed Killer",
                      "Why the Amish Never Get Weeds"]


# ---------------------------------------------------------------- 2. amish

def test_amish_prompt_contents():
    p = am.build_prompt("Why the Amish Never Get Weeds", 15, "Test")
    assert "Elias Yoder" in p
    for name, _lo, _hi in am.SECTIONS:
        assert name in p, f"missing section: {name}"
    for loop in am.CURIOSITY_LOOPS:
        assert loop in p, f"missing loop: {loop}"
    assert "bullet points" in p.lower()
    assert "never use bullet points" in p.lower()
    assert '"hook"' in p and '"beats"' in p and '"cta"' in p
    assert "at least 3 personal stories" in p
    assert "industries profit" in p


def test_amish_scaling():
    for minutes in (5, 15, 30):
        counts = am.section_word_counts(minutes)
        assert len(counts) == 8
        total = sum(w for _, w in counts)
        target = minutes * am.WPM
        assert abs(total - target) <= 0.10 * target, \
            f"{minutes}min: total {total} vs target {target}"
        assert all(w > 0 for _, w in counts)


def test_plain_text_prompt_variant():
    p = am.plain_text_prompt("Test Title", 5)
    assert "Elias Yoder" in p
    assert "Output only the final script" in p
    assert '"beats"' not in p


# ---------------------------------------------------------------- 3. thumbnail

def test_thumbnail_prompt_contents():
    p = th.build_prompt("Why the Amish Never Get Weeds",
                        topic_visual="a weed-free garden bed")
    for bit in ("thick dark eyebrows", "brown eyes",
                "long full salt-and-pepper beard",
                "without a mustache",
                "wide-brimmed straw hat with a black band",
                "white collared shirt", "black suspenders"):
        assert bit in p, f"missing character bit: {bit}"
    for bit in ("Singer treadle", "oil lamps", "sheer curtains"):
        assert bit in p, f"missing background bit: {bit}"
    assert "40%" in p and "60%" in p
    assert "maximum 3 words" in p
    assert "AMISH" in p  # overlay text auto-derived, uppercase


def test_overlay_text_rules():
    cases = [
        "Why the Amish Never Get Weeds in Their Garden",
        "The $3 Trick That Kills Every Snake Instantly!",
        "Stop Buying Fertilizer — Do This Instead",
        "How To Get Free Water Without A Well",
    ]
    for t in cases:
        ov = th.derive_overlay_text(t)
        words = ov.split()
        assert 1 <= len(words) <= 3, f"{t!r} -> {ov!r}"
        assert ov == ov.upper(), f"{t!r} -> {ov!r}"


def test_expression_detection():
    assert th.detect_expression("Kill Every Snake Tonight") == "concerned"
    assert th.detect_expression("The Forgotten Secret Wells") == "surprised"
    assert th.detect_expression("Stop Wasting Money") == "serious"
    assert th.detect_expression("A Calm Garden Morning") == "confident"


# ---------------------------------------------------------------- 4. chain

_FAKE_TOPICS = ["weeds", "snakes", "aphids", "slugs", "mice", "mildew",
                "ants", "wasps", "moles", "cutworms", "blight", "rust",
                "rabbits", "deer", "frost", "drought", "clay soil",
                "compost", "seeds", "tomatoes"]
_FAKE_TITLES = [f"{i + 1}. The $3 Trick That Beats {_FAKE_TOPICS[i].title()}"
                for i in range(20)]


def _fake_meta(url):
    from mib import study
    assert study._video_id(url) == "LK5ZcyHfObI"
    return {"video_id": "LK5ZcyHfObI",
            "url": "https://www.youtube.com/watch?v=LK5ZcyHfObI",
            "title": "Amish Weed Secret", "author": "Homestead TV",
            "description": "", "views": 500000, "published": "2026-01-01",
            "thumbnail_url": "", "thumbnail_path": "", "chapters": []}


def _fake_titles_caller(prompt):
    assert "20" in prompt
    return vt.parse_titles("\n".join(_FAKE_TITLES)), "raw"


def _fake_pipeline(title, channel_id, cfg, secrets, opts,
                   progress_cb=None, log_cb=None):
    assert opts.get("script_style") == "amish", \
        f"chain must force amish, got {opts.get('script_style')}"
    # real thumbnail path: package.run writes thumbnail-prompt.txt
    from mib.stages import package as st_package
    job_dir = Path(tempfile.mkdtemp(prefix="mib-chain-")) / "job"
    job_dir.mkdir(parents=True, exist_ok=True)
    script = {"title": title, "topic": "weeds", "hook": "h",
              "beats": [{"name": n, "narration": "x " * 50,
                         "image_prompt": "scene"}
                        for n in am.BEAT_NAMES],
              "cta": "subscribe", "words": 650, "est_minutes": 5.0}
    st_package.run(str(job_dir), script, {"name": "Test"},
                   "", 300.0, {}, logger=None)
    tp = job_dir / "thumbnail-prompt.txt"
    assert tp.is_file()
    return {"ok": True, "title": title, "job_dir": str(job_dir),
            "final_mp4": "", "duration_s": 300.0,
            "total_cost_usd": 0.0, "qc_reasons": [],
            "thumb_prompt": tp.read_text(encoding="utf-8")}


def test_chain_url_to_thumbnail():
    from mib import autopilot, study
    orig = study.fetch_metadata
    study.fetch_metadata = _fake_meta  # no network in tests
    try:
        res = autopilot.run_chain(
            "https://www.youtube.com/watch?v=LK5ZcyHfObI",
            "chan", {"channels": {"chan": {"name": "Test",
                                           "default_minutes": 5}}}, {},
            titles_caller=_fake_titles_caller,
            pipeline_fn=_fake_pipeline)
    finally:
        study.fetch_metadata = orig
    assert res["ok"], res.get("error")
    assert len(res["titles"]) == 20
    assert res["title"] == res["titles"][0]
    tp = res["pipeline_result"]["thumb_prompt"]
    assert "salt-and-pepper beard" in tp
    assert "suspenders" in tp
    assert "40%" in tp and "60%" in tp


def test_chain_bad_url_graceful():
    from mib import autopilot
    res = autopilot.run_chain(
        "not a url", "chan", {"channels": {}}, {},
        titles_caller=_fake_titles_caller, pipeline_fn=_fake_pipeline)
    assert not res["ok"]
    assert res["error"]


def test_chain_no_key_fallback():
    from mib import autopilot, study
    orig = study.fetch_metadata
    study.fetch_metadata = _fake_meta  # no network in tests
    def _no_key(prompt):
        raise vt.NoKeyError(prompt)
    try:
        res = autopilot.run_chain(
            "https://www.youtube.com/watch?v=LK5ZcyHfObI",
            "chan", {"channels": {}}, {},
            titles_caller=_no_key, pipeline_fn=_fake_pipeline)
    finally:
        study.fetch_metadata = orig
    assert not res["ok"]
    assert res["prompt_text"]  # UI shows the copy-paste dialog


# ---------------------------------------------------------------- 5. UI wiring

def _ui():
    from PySide6.QtWidgets import QApplication
    from mib import config as config_mod
    from mib.ui.settings import SettingsDialog
    from mib.ui.wizard import WizardWindow
    app = QApplication.instance() or QApplication(sys.argv[:1])
    cfg = config_mod.load_config()
    secrets = config_mod.load_secrets()
    cfg.setdefault("channels", {})["c1"] = {
        "name": "Test", "default_minutes": 5, "mode": "avatar"}
    return app, cfg, secrets, SettingsDialog, WizardWindow


def test_settings_script_style():
    _app, cfg, secrets, SettingsDialog, _W = _ui()
    dlg = SettingsDialog(None, cfg, secrets)
    items = [dlg.script_style.itemText(i)
             for i in range(dlg.script_style.count())]
    assert "Competitor-level" in items
    assert "Amish storyteller" in items
    dlg.script_style.setCurrentText("Amish storyteller")
    dlg.save()
    assert cfg["providers"]["script_style"] == "amish"


def test_wizard_title_buttons():
    from PySide6.QtWidgets import QPushButton
    _app, cfg, secrets, _S, WizardWindow = _ui()
    win = WizardWindow(cfg, secrets)
    win.state["channel"] = "c1"
    tp = win.title_page
    labels = [b.text() for b in tp.findChildren(QPushButton)]
    assert any("20 viral titles" in t for t in labels), labels
    assert any("Auto-pilot" in t for t in labels), labels
    assert hasattr(tp, "open_titles") and hasattr(tp, "open_autopilot")


def test_generate_opts_script_style():
    _app, cfg, secrets, _S, WizardWindow = _ui()
    from mib.ui import wizard as wiz_mod
    win = WizardWindow(cfg, secrets)
    win.state["channel"] = "c1"
    cfg["providers"]["script_style"] = "amish"
    captured = {}
    class _StubWorker(wiz_mod.GenWorker):
        def __init__(self, jobs):
            super().__init__(jobs)
            captured["jobs"] = jobs
        def start(self):
            pass
    orig = wiz_mod.GenWorker
    wiz_mod.GenWorker = _StubWorker
    try:
        win.generate_page.start(["t1"])
    finally:
        wiz_mod.GenWorker = orig
    _title, _ch, _cfg, _sec, opts = captured["jobs"][0]
    assert opts.get("script_style") == "amish", opts


# ---------------------------------------------------------------- runner

def _run_all():
    fns = [(n, f) for n, f in sorted(globals().items())
           if n.startswith("test_") and callable(f)]
    passed = 0
    for n, f in fns:
        try:
            f()
        except Exception as e:  # noqa: BLE001
            print(f"FAIL {n}: {e}")
            raise SystemExit(1)
        print(f"ok {n}")
        passed += 1
    print(f"\nALL {passed} CHECKS PASSED")


if __name__ == "__main__":
    _run_all()
