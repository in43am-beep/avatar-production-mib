"""Unit + offscreen UI tests for the 3 new features:

  1. HeyGen provider (estimate_credits, status mapping, generate/poll/
     download with mocked HTTP, quota)
  2. Study flow (decode_mechanics fixture, score_topics, save_study_note)
  3. Scheduler (recommend cadences, Pattern override, plan_label)
  + costs.estimate_label HeyGen variants
  + Settings: heygen KEY_SERVICES row, Channels tab heygen fields
  + Wizard: TitlePage Study button, ChannelPage heygen estimate,
    GeneratePage posting-plan label

Run: QT_QPA_PLATFORM=offscreen MIB_CONFIG_DIR=<tmpdir> python
       test-new-features.py   (this script sets both itself)
"""
import json
import os
import sys
import tempfile
from pathlib import Path

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
os.environ["MIB_CONFIG_DIR"] = tempfile.mkdtemp(prefix="mib-newfeat-")
sys.path.insert(0, str(Path(__file__).resolve().parent))

from PySide6.QtWidgets import QApplication  # noqa: E402

from mib import config as config_mod  # noqa: E402
from mib import costs  # noqa: E402
from mib import scheduler  # noqa: E402
from mib import study  # noqa: E402
from mib.keypool import KeyExhausted, KeyRejected  # noqa: E402
from mib.providers import heygen  # noqa: E402
from mib.ui.settings import SettingsDialog  # noqa: E402
from mib.ui.wizard import WizardWindow  # noqa: E402

app = QApplication(sys.argv[:1])
passed = []


def check(name, cond, extra=""):
    assert cond, f"FAIL {name}: {extra}"
    passed.append(name)
    print(f"  {name}: OK")


# ============ 1. HeyGen provider ============
print("== HeyGen provider ==")
check("hg-est-avatar3", heygen.estimate_credits(120, "avatar3") == 2.0)
check("hg-est-avatar4", heygen.estimate_credits(120, "avatar4") == 8.0)
check("hg-est-10s", heygen.estimate_credits(10, "avatar3") == 0.17)
check("hg-cpm",
      heygen.ENGINES["avatar4"]["credits_per_min"] == 4.0
      and heygen.ENGINES["avatar3"]["credits_per_min"] == 1.0)
check("hg-usd", heygen.estimate_usd(8.0) == 8.0)
check("hg-engines-label",
      "Avatar III" in heygen.ENGINES["avatar3"]["label"])
# failover mapping: HeyGenExhausted is a KeyExhausted, HeyGenRejected a
# KeyRejected — KeyPool rotates on both.
check("hg-exc-map",
      issubclass(heygen.HeyGenExhausted, KeyExhausted)
      and issubclass(heygen.HeyGenRejected, KeyRejected))


class FakeResp:
    def __init__(self, status_code, body=None, content=b"",
                 ctype="application/json"):
        self.status_code = status_code
        self._body = body if body is not None else {}
        self.content = content
        self.headers = {"Content-Type": ctype}
        self.text = json.dumps(self._body)

    def json(self):
        return self._body

    def iter_content(self, chunk_size=65536):
        yield self.content


for code, exc in [(429, heygen.HeyGenExhausted),
                  (401, heygen.HeyGenRejected),
                  (403, heygen.HeyGenRejected),
                  (402, heygen.HeyGenRejected)]:
    try:
        heygen._raise(FakeResp(code, {"message": "x"}))
        check(f"hg-status-{code}", False, "no exception raised")
    except exc:
        check(f"hg-status-{code}", True)
    except Exception as e:  # noqa: BLE001
        check(f"hg-status-{code}", False, f"wrong exc {type(e).__name__}")
heygen._raise(FakeResp(200))
check("hg-ok-no-raise", True)


class StubRQ:
    def post(self, url, headers=None, json=None, timeout=None):
        assert "/v2/video/generate" in url
        assert (headers or {}).get("x-api-key") == "key"
        assert json["video_inputs"][0]["character"]["avatar_id"] == "av1"
        return FakeResp(200, {"data": {"video_id": "vid123"}})

    def get(self, url, headers=None, params=None, timeout=None, stream=False):
        if "video_status" in url:
            return FakeResp(200, {"data": {"status": "completed",
                                           "video_url": "https://cdn/x.mp4"}})
        if "remaining_quota" in url:
            return FakeResp(200, {"data": {"remaining_quota": 25.5}})
        if "avatars" in url:
            return FakeResp(200, {"data": {"avatars": [
                {"avatar_id": "a1", "avatar_name": "Anna", "gender": "F"}]}})
        return FakeResp(200, content=b"FAKEMP4", ctype="video/mp4")


orig_requests, orig_sleep = heygen.requests, heygen.time.sleep
heygen.requests = StubRQ()
heygen.time.sleep = lambda s: None
try:
    res = heygen.generate_video("key", "av1", "hello world", poll_interval=0)
    check("hg-generate", res.get("video_id") == "vid123"
          and res.get("video_url") == "https://cdn/x.mp4", res)
    dst = Path(os.environ["MIB_CONFIG_DIR"]) / "hg.mp4"
    out = heygen.download_video("https://cdn/x.mp4", str(dst))
    check("hg-download", out and dst.is_file()
          and dst.read_bytes() == b"FAKEMP4")
    check("hg-quota", heygen.get_quota("key") == 25.5)
    avs = heygen.list_avatars("key")
    check("hg-avatars", len(avs) == 1 and avs[0]["avatar_id"] == "a1"
          and avs[0]["avatar_name"] == "Anna", avs)
finally:
    heygen.requests = orig_requests
    heygen.time.sleep = orig_sleep

# KeyPool rotates across heygen keys on 429 (failover)
from mib.keypool import KeyPool  # noqa: E402


class RotStub:
    def __init__(self):
        self.n = 0

    def post(self, url, headers=None, json=None, timeout=None):
        self.n += 1
        if self.n == 1:
            return FakeResp(429, {"message": "rate limit"})
        return FakeResp(200, {"data": {"video_id": "vid2"}})

    def get(self, url, headers=None, params=None, timeout=None, stream=False):
        return FakeResp(200, {"data": {"status": "completed",
                                       "video_url": "https://cdn/v.mp4"}})


heygen.requests = RotStub()
heygen.time.sleep = lambda s: None
try:
    pool = KeyPool("heygen", ["bad-key", "good-key"],
                   state_dir=Path(os.environ["MIB_CONFIG_DIR"]))
    res = pool.run(lambda k: heygen.generate_video(
        k, "av1", "hi", poll_interval=0), op="avatar")
    check("hg-failover", res.get("video_id") == "vid2", res)
finally:
    heygen.requests = orig_requests
    heygen.time.sleep = orig_sleep


# ============ 2. Study flow ============
print("== Study flow ==")
fixture_meta = {
    "title": "7 Garden Mistakes Killing Your Plants (4K)",
    "author": "Test Gardener",
    "description": "Buy the book here: http://x\n00:00 intro\n02:30 "
                   "mistake one\n\nGet my newsletter http://y",
    "views": 123456,
    "published": "2026-09-01",
    "chapters": [{"t": "00:00", "label": "intro"},
                 {"t": "02:30", "label": "mistake one"}],
}
# thumbnail fixture: small white image -> bright
try:
    from PIL import Image
    img = Image.new("RGB", (40, 22), (240, 235, 230))
    td = Path(os.environ["MIB_CONFIG_DIR"])
    img.save(td / "thumb.jpg")
    fixture_meta["thumbnail_path"] = str(td / "thumb.jpg")
except Exception:  # noqa: BLE001
    pass

mech = study.decode_mechanics(fixture_meta)
tf = mech.get("title_formula") or {}
check("st-numbers", tf.get("numbers") == ["7", "4"], tf)
check("st-brackets", tf.get("bracket_tags") == ["(4K)"], tf)
check("st-case", tf.get("case") == "Title Case", tf)
check("st-hook", mech.get("hook") == "Buy the book here: http://x",
      repr(mech.get("hook")))
check("st-chapters", len(mech.get("chapters") or []) == 2,
      mech.get("chapters"))
check("st-cta-order", (mech.get("description") or {}).get("cta_order") == [
      "tagline", "chapters", "chapters", "tagline"],
      mech.get("description"))
td2 = mech.get("thumbnail") or {}
check("st-thumb-bright", td2.get("brightness") == "bright", td2)

pattern = {"tone": "warm, slow, reassuring", "promise": "save money",
           "banned": []}
topics = study.score_topics(fixture_meta, mech, pattern, "garden")
check("st-10topics", len(topics) == 10, len(topics))
check("st-not-copied",
      all(t["title"] != fixture_meta["title"] for t in topics))
check("st-scores", all(0 <= t["score"] <= 10 for t in topics))
check("st-sorted", topics[0]["score"] >= topics[-1]["score"])
titles = [t["title"] for t in topics]
check("st-unique", len(set(titles)) == 10, titles)

# graceful failure
bad = study.decode_mechanics({})
check("st-bad-meta", bad.get("title_formula") == {} or True)  # never raises
meta_err = study.fetch_metadata("not-a-url")
check("st-bad-url", "error" in meta_err, meta_err)

note = Path(os.environ["MIB_CONFIG_DIR"]) / "note.md"
ok = study.save_study_note(str(note), fixture_meta, mech, topics)
check("st-note", ok and note.is_file())
txt = note.read_text(encoding="utf-8")
check("st-note-content",
      "# Study —" in txt and "7 Garden Mistakes" in txt
      and "Title formula" in txt and "Generated topics" in txt
      and topics[0]["title"] in txt)

# ============ 3. Scheduler ============
print("== Scheduler ==")
check("sched-30", scheduler.recommend(
    {"default_minutes": 30}, {}).get("videos_per_week") == 2)
check("sched-12", scheduler.recommend(
    {"default_minutes": 12}, {}).get("videos_per_week") == 3)
check("sched-7", scheduler.recommend(
    {"default_minutes": 7}, {}).get("videos_per_week") == 4)
check("sched-3", scheduler.recommend(
    {"default_minutes": 3}, {}).get("videos_per_week") == 5)
check("sched-override", scheduler.recommend(
    {"default_minutes": 30},
    {"cadence_per_week": 6}).get("videos_per_week") == 6)
rec = scheduler.recommend({"default_minutes": 30}, {})
check("sched-slots", len(rec["slots"]) == 3 and rec["slots"][0].startswith(
    "Tue"), rec["slots"])
check("sched-label",
      "📅" in scheduler.plan_label(rec) and "2/week" in
      scheduler.plan_label(rec) and "Tue" in
      scheduler.plan_label(rec), scheduler.plan_label(rec))
check("sched-note", "uploads stay manual" in rec["note"].lower(),
      rec["note"])

# ============ 4. costs estimate_label HeyGen variants ============
print("== costs ==")
ch = {"default_minutes": 30}
check("cost-off", costs.estimate_label(ch, {}, {}) ==
      "$0.00/min (all local, free)", costs.estimate_label(ch, {}, {}))
on = {"heygen_enabled": True}
check("cost-on-key", "HeyGen credits/min" in
      costs.estimate_label(ch, {"heygen_api_key": "k"}, on),
      costs.estimate_label(ch, {"heygen_api_key": "k"}, on))
check("cost-on-nokey", "no key" in
      costs.estimate_label(ch, {}, on),
      costs.estimate_label(ch, {}, on))

# ============ 5. Settings UI ============
print("== Settings UI ==")
cfg = config_mod.load_config()
secrets = config_mod.load_secrets()
dlg = SettingsDialog(None, cfg, secrets)
svc_ids = [s[0] for s in SettingsDialog.KEY_SERVICES]
check("set-heygen-service", "heygen" in svc_ids, svc_ids)
# API Keys tab: find the service label
found = False
for child in dlg.findChildren(type(dlg)) :
    pass
labels = dlg.findChildren(__import__("PySide6.QtWidgets", fromlist=[
    "QLabel"]).QLabel)
found = any("HeyGen" in (l.text() or "") for l in labels)
check("set-heygen-row", found)
# Channels tab fields
check("set-hg-fields",
      hasattr(dlg, "hg_enable") and hasattr(dlg, "hg_avatar")
      and hasattr(dlg, "hg_voice") and hasattr(dlg, "hg_engine"))
# channels tab: set values -> apply -> persist
cfg["channels"] = {"c1": {"name": "Test", "default_minutes": 30}}
config_mod.save_config(cfg)
dlg2 = SettingsDialog(None, cfg, secrets)
# select channel c1
idx = dlg2.ch_pick.findData("c1")
check("set-ch1", idx >= 0)
dlg2.ch_pick.setCurrentIndex(idx)
dlg2.hg_enable.setChecked(True)
dlg2.hg_avatar.setText("av_test_1")
dlg2.hg_voice.setText("v_test_1")
dlg2.hg_engine.setCurrentIndex(1)  # avatar4
dlg2.apply_channel()
cfg3 = config_mod.load_config()
ch1 = cfg3["channels"]["c1"]
check("set-save",
      ch1.get("heygen_avatar_id") == "av_test_1"
      and ch1.get("heygen_voice_id") == "v_test_1"
      and cfg3["providers"].get("heygen_enabled") is True
      and cfg3["providers"].get("heygen_engine") == "avatar4",
      json.dumps({k: ch1.get(k) for k in ("heygen_avatar_id",
                 "heygen_voice_id")}) + " " + json.dumps({
                     k: cfg3["providers"].get(k)
                     for k in ("heygen_enabled", "heygen_engine")}))
# reload -> fields repopulate
dlg3 = SettingsDialog(None, cfg3, secrets)
idx = dlg3.ch_pick.findData("c1")
dlg3.ch_pick.setCurrentIndex(idx)
check("set-reload",
      dlg3.hg_enable.isChecked()
      and dlg3.hg_avatar.text() == "av_test_1"
      and dlg3.hg_voice.text() == "v_test_1"
      and dlg3.hg_engine.currentData() == "avatar4")

# ============ 6. Wizard UI ============
print("== Wizard UI ==")
win = WizardWindow(config_mod.load_config(), config_mod.load_secrets())
# TitlePage: Study button
from PySide6.QtWidgets import QPushButton, QLabel  # noqa: E402
tp = win.title_page
study_btns = [b for b in tp.findChildren(QPushButton)
              if "Study" in (b.text() or "")]
check("wiz-study-btn", len(study_btns) >= 1)
check("wiz-study-opens", hasattr(tp, "open_study"))
# ChannelPage: heygen estimate on card when enabled + key
cp = win.channel_page
win.cfg["providers"] = {"heygen_enabled": True}
win.secrets["heygen_api_key"] = "k"
cp.refresh()
cards = [w for w in cp.findChildren(QLabel) if "/min" in (w.text() or "")]
check("wiz-card-heygen", any("HeyGen credits" in w.text() for w in cards),
      [w.text() for w in cards][:3])
# GeneratePage: posting-plan label
gp = win.generate_page
win.cfg["channels"] = {"c1": {"name": "Test", "default_minutes": 30}}
win.state["channel"] = "c1"
gp.refresh_plan()
check("wiz-plan", "📅" in gp.plan_lbl.text()
      and "2/week" in gp.plan_lbl.text(), gp.plan_lbl.text())
# PresenterPage: heygen cost label
pp = win.presenter_page
win.cfg["providers"] = {"heygen_enabled": True, "heygen_engine": "avatar3"}
pp.update_cost()
check("wiz-pres-heygen", "HeyGen" in pp.cost_lbl.text()
      and "credits" in pp.cost_lbl.text(), pp.cost_lbl.text())
win.cfg["providers"] = {}
pp.update_cost()
check("wiz-pres-local", "local, free" in pp.cost_lbl.text(),
      pp.cost_lbl.text())

print(f"\nALL {len(passed)} CHECKS PASSED")
