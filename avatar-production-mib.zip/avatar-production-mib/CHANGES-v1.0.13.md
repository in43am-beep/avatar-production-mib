# v1.0.13 changes (pending release, 2026-09-25)

## 1. HeyGen talking-head provider — ADDED (opt-in, paid)
`mib/providers/heygen.py` + avatar-stage wiring: when enabled and a HeyGen
API key is present, the avatar stage renders the whole narration as one
HeyGen talking-head video (avatar3 ~1 credit/min | avatar4 ~4 credits/min)
and cuts the cold-open/chapter/interlude presenter clips from it at the
same plan positions. Credit→USD conversion lives in the cost ledger
(`costs.py` UNIT_PRICES); the pre-run estimate, pipeline log line and job
`costs.json` all show the estimate. Any failure (no key, no avatar id,
API error) falls back silently to the free static presenter mechanics —
the pipeline never stalls. Enable per channel: Settings → Channels →
"Use HeyGen talking-head"; avatar id per channel, engine global; keys in
Settings → API Keys → heygen (same key-pool failover + Verify board as
every other service).

## 2. "Study" flow — ADDED (competitor decode → topic candidates)
Paste any competitor YouTube video URL (wizard Channel/Title step →
"Study" button) and the app fetches its metadata (title, description,
views, chapters, thumbnail) and decodes the packaging mechanics
(title formula, hook structure, chapter pattern) into 10 topic candidates
scored against the channel's Pattern profile. The user approves picks
into the normal batch flow. A markdown study note is saved per study in
the video folder. Study-only: nothing is ever copied — mechanics are
decoded, topics are original.

## 3. Upload-strategy scheduler — ADDED (advisory, no auto-upload)
`mib/scheduler.py`: per-channel posting cadence + best-time slots shown in
the queue UI. Advisory only — the app never uploads by itself.

## 4. LongCat local talking-head — EVALUATED AND DROPPED
LongCat-Video-Avatar-1.5 (MIT, audio-driven talking head) was studied and
half-integrated as a free/local HeyGen alternative, then removed before
release: it needs a 16 GB+ NVIDIA GPU and the target machine has a
GTX 1660 Ti (6 GB VRAM), so it could never run for this user. All
LongCat code, UI, config keys, cost-ledger hooks and the setup script
were removed cleanly — zero references remain. LiveAvatar was rejected
for the same reason (needs 48–80 GB VRAM). HeyGen (cloud, paid, opt-in)
stays the ONLY animated talking-head path; the free/local default stays
the static presenter mechanics (fast, deterministic, seconds to render).
