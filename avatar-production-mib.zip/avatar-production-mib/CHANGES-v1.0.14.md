# v1.0.14 changes (pending release, 2026-09-25)

## 1. VIRAL TITLE GENERATOR — ADDED (wizard Title step)
"✨ 20 viral titles…" button on the wizard Title step. Sends the user's
own title prompt (20 ideas, 100K–1M+ potential, 6 audiences, 15
categories, 8 proven structures, ranked strongest-first) to the
script-LLM key pool — Gemini or AI33 Pro, whichever is selected in
Settings → Script → Provider (`mib/providers/geminillm.py` /
`scriptllm.py` `generate_text()`). Parsed titles show ranked in a
checkable list (top 3 pre-ticked); "Add selected to batch" drops them
into the normal flow. New module `mib/prompts/viral_titles.py` holds
the pure prompt builder + parser; with no key configured the app shows
the built prompt in a copy-paste dialog (free/local fallback).

## 2. AMISH STORYTELLER SCRIPT MODE — ADDED (Script tab selector)
Settings → Script now has a "Script style" selector: "Competitor-level"
(default, unchanged) vs "Amish storyteller". In storyteller mode the
script LLM (Gemini/AI33 Pro) writes the full narration in the voice of
Amish farmer Elias Yoder, following the user's spec exactly: shocking
pain-point hook, ancestral knowledge, hidden secret, the
industries-profit-from-ignorance angle, ≥3 personal stories, ≥2
neighbour examples, curiosity loops ("But that's not the most
important part…", "What happened next shocked me…", "Nobody talks
about this anymore…"), never bullet points, continuous voice-over
narration, next-video teaser ending. 8 sections with word counts scaled
proportionally to target minutes × 130 wpm (±10%):
HOOK (300–500) · AUTHORITY + STORY (500–1000) · THE HIDDEN SECRET
(1000–2000) · WHY MODERN PEOPLE GOT IT WRONG (1000–1500) ·
STEP-BY-STEP METHOD (1000–2000) · COMMON MISTAKES (500–1000) ·
FINAL LESSON (500–1000) · NEXT VIDEO TEASER (200–300).
New module `mib/prompts/amish_script.py`; providers gained
`build_amish_prompt()` + `generate_amish()` returning the standard
script dict with 8 beats (voiceover/images/assemble/QC iterate beats
generically — no other stage changes). Saved per-provider in config
(`providers.script_style`); honoured by the pipeline and the wizard
Generate opts; logged as `[gemini-llm amish]` / `[ai33pro-llm amish]`.
Local rules engine keeps competitor mechanics — Amish mode needs an
LLM key (logged clearly, graceful fallback).

## 3. THUMBNAIL PROMPT TEMPLATE — ADDED (locked character)
New module `mib/prompts/thumbnail.py` implementing the user's template:
locked main character (close-up Amish man, thick dark eyebrows, brown
eyes, long full salt-and-pepper beard WITHOUT mustache, wide-brim
straw hat with black band, white collared shirt, black suspenders),
farmhouse interior (white walls, wooden window frames, sheer curtains,
Singer treadle machine, dresser with oil lamps, hanging wooden tools),
photorealistic/cinematic/HDR/8K, 40% character / 60% problem-or-solution
composition, overlay text auto-derived from the title (≤3 words,
UPPERCASE, `derive_overlay_text()`), expression picked from the topic
(`detect_expression()`). `mib/stages/package.py` now writes this
template to each video's `thumbnail-prompt.txt` (the image-gen input
when an image key is enabled; otherwise the prompt file stays the
free fallback).

## 4. AUTO-PILOT: reference URL → full video — ADDED (Title step)
"🤖 Auto-pilot from URL…" button on the wizard Title step. Paste a
reference YouTube video URL and press Start: the app studies the video
(public metadata, packaging formulas only), generates 20 viral titles,
takes the top-ranked title, runs the full pipeline in Amish storyteller
mode, and writes the locked-character thumbnail prompt — zero manual
steps in between. New modules `mib/autopilot.py` (UI-free,
testable chain) and `mib/ui/autopilot_dialog.py` (progress + live log).
Fetch failures and missing keys degrade gracefully with clear
messages (title step shows the copy-paste prompt when no script-LLM
key is set).

## 5. Version constant — ADDED
`mib/__init__.py` now carries `__version__ = "1.0.14"` (previous
releases were tagged by CHANGES files + git tags only).

## Tests
New `tests/test_viral_prompts.py` covers all three prompt builders
plus the URL→titles→script→thumbnail chain (no network). Full suite
(selftest + existing test-*.py scripts + pytest) green.
