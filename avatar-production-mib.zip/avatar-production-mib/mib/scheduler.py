"""mib/scheduler.py — ADVISORY posting-plan recommendations.

No automation: the app never posts, uploads, or schedules anything on
YouTube. This module just suggests a cadence (videos/week) + best-time
posting slots per channel, derived from the channel's Pattern profile
with simple defaults, shown as a small panel in the Generate step.

Heuristics are intentionally simple and transparent:
  - longer videos (more production) -> fewer per week
  - a Pattern profile can override cadence_per_week
  - slots default to evening weekday + weekend morning windows that
    senior audiences tend to favour (advisory only — the user decides)

Pure functions, never raise.
"""

DEFAULT_SLOTS = ["Tue 7:00 PM", "Thu 7:00 PM", "Sat 10:00 AM"]


def recommend(channel_cfg, pattern=None):
    """Return {"videos_per_week", "slots", "note"} for a channel.

    channel_cfg: the channel dict (default_minutes etc.)
    pattern: the channel's Pattern profile (optional) — honours
      pattern.get("cadence_per_week") when it's a positive number.
    Never raises.
    """
    try:
        ch = channel_cfg or {}
        pat = pattern or {}
        cadence = 0
        try:
            cadence = int(pat.get("cadence_per_week") or 0)
        except (TypeError, ValueError):
            cadence = 0
        if cadence <= 0:
            try:
                mins = int(ch.get("default_minutes") or 5)
            except (TypeError, ValueError):
                mins = 5
            if mins >= 20:
                cadence = 2
            elif mins >= 10:
                cadence = 3
            elif mins >= 5:
                cadence = 4
            else:
                cadence = 5
        slots = list(pat.get("posting_slots") or DEFAULT_SLOTS)[:3]
        mode = "pattern override" if pat.get("cadence_per_week") else "default"
        note = (f"{cadence} video(s)/week suggested "
                f"({mode}; {int(ch.get('default_minutes') or 5)} min "
                f"target). Advisory only — uploads stay manual.")
        return {"videos_per_week": cadence, "slots": slots, "note": note}
    except Exception:  # noqa: BLE001
        return {"videos_per_week": 3, "slots": list(DEFAULT_SLOTS),
                "note": "defaults (advisory only)"}


def plan_label(rec):
    """One-line label for the UI panel. Never raises."""
    try:
        rec = rec or {}
        slots = ", ".join(rec.get("slots") or [])
        return (f"📅 Suggested posting plan (advisory): "
                f"{rec.get('videos_per_week', 3)}/week · {slots}")
    except Exception:  # noqa: BLE001
        return "📅 Suggested posting plan: 3/week"
