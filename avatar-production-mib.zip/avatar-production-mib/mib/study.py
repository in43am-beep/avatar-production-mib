"""mib/study.py — viral-topic "Study" flow.

The user pastes a competitor YouTube video URL; the app fetches its
metadata at RUNTIME on the user's own PC via plain public web requests
(oEmbed + the watch page) — NO YouTube API key, no login — then:

  1. decodes the packaging mechanics into the channel-studies style
     (title formula, thumbnail formula, description CTA order, hook);
  2. generates 10 topic candidates in the SAME niche, scored against the
     channel's existing Pattern profile;
  3. the user picks/approves topics into the normal batch flow (wizard
     Title step), and the study is saved as a markdown note.

All functions are exception-proof: fetch_metadata returns {"error": ...}
on any failure (unreachable, private, removed, non-YouTube URL) so the
UI can show a clear message instead of crashing.

Study first, produce second: decode the craft, never copy the content.
The generated topics are ORIGINAL — they reuse the FORMULAS (numbers,
brackets, case, cadence), never anyone's titles or footage.
"""
import json
import re
import urllib.parse
from pathlib import Path

UA = {"User-Agent": ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                     "AppleWebKit/537.36 (KHTML, like Gecko) "
                     "Chrome/120.0 Safari/537.36")}

STOPWORDS = frozenset(
    "the a an and or but of to in on for with from at by is are was were "
    "be been being it its this that these those as we you they he she him "
    "her them us our your their my me do does did not no yes if then than "
    "so such just only how why what when where who which will would can "
    "could should there here out up down over under again very much more "
    "most into like".split())

_TITLE_FORMULA_TWISTS = [
    "Nobody Saw This Coming", "Nobody Expected This",
    "Experts Were Wrong", "Changed Everything",
    "Nobody Talks About This", "Nobody Believed It Would Work",
    "The Neighbors Were Shocked", "It Saved the Whole Season",
    "Grandma's Secret Method", "The Old Way Still Wins",
]

_BRACKET_TAGS = ["(Nobody Saw This Coming)", "(Full Breakdown)",
                "(Step by Step)", "(What Experts Won't Tell You)",
                "(The Truth)", "(Before It's Too Late)"]


# ---------------------------------------------------------------- fetching

def _video_id(url):
    """Extract the 11-char video id from a YouTube URL. Returns '' or id."""
    try:
        u = str(url or "").strip()
        m = re.search(r"(?:v=|youtu\.be/|/shorts/|/embed/)([A-Za-z0-9_-]{11})",
                      u)
        return m.group(1) if m else ""
    except Exception:  # noqa: BLE001
        return ""


def _get(url, timeout=15):
    import requests
    resp = requests.get(url, headers=UA, timeout=timeout)
    return resp


def _oembed(url, vid):
    """Fast public metadata: title, author, thumbnail. Never raises."""
    out = {}
    try:
        api = ("https://www.youtube.com/oembed?url="
               + urllib.parse.quote(
                   f"https://www.youtube.com/watch?v={vid}", safe="")
               + "&format=json")
        resp = _get(api)
        if resp.status_code != 200:
            return {}
        data = resp.json()
        out["title"] = str(data.get("title", "") or "")
        out["author"] = str(data.get("author_name", "") or "")
        out["thumbnail_url"] = str(data.get("thumbnail_url", "") or "")
    except Exception:  # noqa: BLE001
        pass
    return out


def _parse_watch_page(vid):
    """Parse the public watch page for description, views, chapters.

    Chapters are recovered from timestamped description lines
    ("0:00 Intro") — the same format YouTube itself turns into chapters.
    Never raises; returns {} on any failure.
    """
    out = {}
    try:
        html = _get(f"https://www.youtube.com/watch?v={vid}",
                    timeout=20).text or ""
    except Exception:  # noqa: BLE001
        return out
    if not html:
        return out

    # description (og:description, decoded from HTML entities)
    try:
        m = re.search(r'<meta[^>]+property="og:description"[^>]+content="([^"]*)"',
                      html)
        if not m:
            m = re.search(r'<meta[^>]+content="([^"]*)"[^>]+'
                          r'property="og:description"', html)
        if m:
            import html as _html
            out["description"] = _html.unescape(m.group(1))
    except Exception:  # noqa: BLE001
        pass

    # view count (embedded player response)
    try:
        m = re.search(r'"viewCount"\s*:\s*"(\d+)"', html)
        if m:
            out["views"] = int(m.group(1))
        else:
            m = re.search(r'"viewCount"\s*:\s*(\d+)', html)
            if m:
                out["views"] = int(m.group(1))
    except Exception:  # noqa: BLE001
        pass

    # chapters from timestamped description lines
    try:
        chapters = []
        desc = out.get("description", "")
        for line in desc.splitlines():
            line = line.strip()
            m = re.match(r"^(\d{1,3}):(\d{2})(?::(\d{2}))?\s+(.+)$", line)
            if m and m.group(4).strip():
                chapters.append({"ts": m.group(1) + ":" + m.group(2)
                                 + ((":" + m.group(3)) if m.group(3) else ""),
                                 "label": m.group(4).strip()[:80]})
        out["chapters"] = chapters
    except Exception:  # noqa: BLE001
        out["chapters"] = []

    # published date (best effort)
    try:
        m = re.search(r'"uploadDate"\s*:\s*"([^"]+)"', html)
        if m:
            out["published"] = m.group(1)[:10]
    except Exception:  # noqa: BLE001
        pass
    return out


def _download_thumbnail(thumb_url, dest_dir, vid):
    """Save the thumbnail image. Returns path str or ''. Never raises."""
    try:
        if not thumb_url:
            return ""
        d = Path(dest_dir)
        d.mkdir(parents=True, exist_ok=True)
        dest = d / f"{vid}-thumb.jpg"
        resp = _get(thumb_url, timeout=20)
        if resp.status_code == 200 and resp.content:
            dest.write_bytes(resp.content)
            return str(dest)
    except Exception:  # noqa: BLE001
        pass
    return ""


def fetch_metadata(url, thumb_dir=None):
    """Fetch a competitor video's metadata at runtime on the user's PC.

    Returns {"video_id", "url", "title", "author", "description",
             "views", "published", "thumbnail_url", "thumbnail_path",
             "chapters"} — or {"error": "<clear reason>"} on failure.
    Never raises.
    """
    try:
        url = (url or "").strip()
        vid = _video_id(url)
        if not vid:
            return {"error": "That doesn't look like a YouTube video URL. "
                             "Paste a full watch link (youtube.com/watch?v=… "
                             "or youtu.be/…)."}
        if "youtube.com" not in url and "youtu.be" not in url:
            return {"error": "Only YouTube video URLs are supported."}

        meta = {"video_id": vid,
                "url": f"https://www.youtube.com/watch?v={vid}"}
        try:
            oe = _oembed(url, vid)
        except Exception:  # noqa: BLE001
            oe = {}
        if not oe.get("title"):
            # oEmbed 401/404 = private / removed / age-restricted
            return {"error": "Couldn't reach that video — it may be "
                             "private, removed, or region-restricted. "
                             "Try a public video URL."}
        meta.update(oe)
        page = _parse_watch_page(vid)
        meta.setdefault("description", page.get("description", ""))
        meta.setdefault("views", page.get("views", 0))
        meta.setdefault("published", page.get("published", ""))
        meta.setdefault("chapters", page.get("chapters", []))
        if thumb_dir:
            meta["thumbnail_path"] = _download_thumbnail(
                meta.get("thumbnail_url", ""), thumb_dir, vid)
        else:
            meta["thumbnail_path"] = ""
        return meta
    except Exception as e:  # noqa: BLE001
        return {"error": f"Fetch failed: {e}"[:300]}


# ---------------------------------------------------------------- decoding

def _title_case_style(title):
    t = (title or "").strip()
    letters = [c for c in t if c.isalpha()]
    if not letters:
        return "n/a"
    if all(c.isupper() for c in letters):
        return "ALL CAPS"
    if all(c.islower() for c in letters):
        return "lowercase"
    if t.istitle():
        return "Title Case"
    words = t.split()
    if words and sum(1 for w in words if w and w[0].isupper()) >= len(words) * 0.6:
        return "Headline Case"
    return "sentence case"


def decode_mechanics(meta):
    """Decode packaging mechanics, channel-studies style. Pure function.

    Returns {"title_formula", "thumbnail", "description", "hook",
             "chapters", "verdict"}. Never raises.
    """
    try:
        meta = meta or {}
        title = str(meta.get("title") or "")
        desc = str(meta.get("description") or "")

        numbers = re.findall(r"\$?[\d,]+(?:\.\d+)?", title)
        brackets = re.findall(r"[\(\[][^)\]]+[\)\]]", title)
        title_formula = {
            "length": len(title),
            "case": _title_case_style(title),
            "numbers": numbers,
            "has_number": bool(numbers),
            "bracket_tags": brackets,
            "has_brackets": bool(brackets),
            "questions": title.count("?"),
            "exclamations": title.count("!"),
            "first_words": " ".join(title.split()[:4]),
        }

        # thumbnail: visual facts we can measure locally (Pillow, optional)
        thumb = {"path": meta.get("thumbnail_path", ""),
                 "size": "", "brightness": "", "dominant_colors": []}
        try:
            p = Path(thumb.get("path") or "")
            if p.is_file():
                from PIL import Image
                im = Image.open(p).convert("RGB")
                w, h = im.size
                thumb["size"] = f"{w}×{h}"
                small = im.resize((16, 16))
                px = list(small.getdata())
                avg = sum(sum(c) for c in px) / (len(px) * 3)
                thumb["brightness"] = ("dark" if avg < 70
                                       else "mid" if avg < 150 else "bright")
                cols = im.resize((4, 4)).getdata()
                seen = []
                for c in cols:
                    hexed = "#%02x%02x%02x" % c
                    if hexed not in seen:
                        seen.append(hexed)
                thumb["dominant_colors"] = seen[:6]
        except Exception:  # noqa: BLE001
            pass

        # description: classify the first lines -> CTA order
        desc_lines = [l.strip() for l in desc.splitlines()]
        first = [l for l in desc_lines if l][:8]
        cta_order = []
        for l in first:
            if re.match(r"^https?://|www\.", l):
                cta_order.append("link")
            elif l.startswith("#"):
                cta_order.append("hashtags")
            elif re.match(r"^\d{1,3}:\d{2}", l):
                cta_order.append("chapters")
            elif l.endswith("?"):
                cta_order.append("question")
            elif len(l) <= 60:
                cta_order.append("tagline")
            else:
                cta_order.append("prose")
        hook = ""
        for l in first:
            if len(l) > 20:
                hook = l[:160]
                break

        return {
            "title_formula": title_formula,
            "thumbnail": thumb,
            "description": {
                "length": len(desc),
                "cta_order": cta_order,
                "line_count": len(desc_lines),
                "has_disclosure": bool(re.search(
                    r"affiliate|sponsored|disclosure", desc, re.I)),
            },
            "hook": hook,
            "chapters": meta.get("chapters") or [],
            "views": meta.get("views", 0),
            "verdict": ("original-packaging decode — formulas only, "
                        "never the content"),
        }
    except Exception:  # noqa: BLE001
        return {"title_formula": {}, "thumbnail": {}, "description": {},
                "hook": "", "chapters": [], "views": 0, "verdict": ""}


# ---------------------------------------------------------------- topic scoring

def _niche_keywords(pattern, niche_text):
    """Keyword set from the channel niche + pattern notes."""
    try:
        words = []
        for src in ((niche_text or ""), (pattern or {}).get("style_notes", ""),
                    (pattern or {}).get("image_style", "")):
            for w in re.findall(r"[a-z]{4,}", str(src).lower()):
                if w not in STOPWORDS:
                    words.append(w)
        return set(words)
    except Exception:  # noqa: BLE001
        return set()


def _study_seeds(title):
    """Topic seeds from the study video title: strip numbers/brackets/
    stopwords, keep the meaty nouns."""
    try:
        t = re.sub(r"[\(\[][^\]\)]*[\]\)]", " ", title or "")
        t = re.sub(r"\$?[\d,]+(?:\.\d+)?", " ", t)
        words = [w for w in re.findall(r"[A-Za-z]{4,}", t.lower())
                 if w not in STOPWORDS]
        seen, out = set(), []
        for w in words:
            if w not in seen:
                seen.add(w)
                out.append(w)
        return out[:8]
    except Exception:  # noqa: BLE001
        return []


def _title_templates(seeds, pattern):
    """Render 10 ORIGINAL titles from study formulas + pattern hooks.

    Uses the study's PACKAGING formulas (numbers, brackets, case) with
    original topic seeds — never the study's own titles.
    """
    try:
        seeds = seeds or ["garden"]
        out = []
        for i in range(10):
            s = seeds[i % len(seeds)].replace("-", " ").title()
            tmpl = i % 5
            if tmpl == 0:
                t = (f"The {s} Secret That {s} Growers Never Share "
                     f"{_BRACKET_TAGS[i % len(_BRACKET_TAGS)]}")
            elif tmpl == 1:
                n = 5 + (i * 3) % 8
                t = (f"{n} {s} Mistakes That Are Killing Your "
                     f"{seeds[(i + 1) % len(seeds)].title()} "
                     f"(Fix #{1 + (i % 3)})")
            elif tmpl == 2:
                t = (f"Why {s} Works When Nothing Else Does — "
                     f"{_TITLE_FORMULA_TWISTS[i % len(_TITLE_FORMULA_TWISTS)]}")
            elif tmpl == 3:
                t = (f"I Tried {s} for 30 Days — Here's What Happened "
                     f"{_BRACKET_TAGS[(i + 2) % len(_BRACKET_TAGS)]}")
            else:
                t = f"What {s} Really Does to Your Soil (The Truth)"
            out.append(t[:90])
        return out
    except Exception:  # noqa: BLE001
        return []


def score_topics(meta, mechanics, pattern, niche_text):
    """Generate 10 scored ORIGINAL topic candidates in the same niche.

    Scoring vs the channel Pattern profile:
      +2 per niche keyword in the title · +2 has a number · +2 has a
      bracket tag · +2 hook-template word overlap · +1 length 40–70 ·
      +1 question or em-dash. Max 10. Never raises.
    """
    try:
        pat = pattern or {}
        niche_kw = _niche_keywords(pat, niche_text)
        seeds = _study_seeds((meta or {}).get("title", ""))
        hook_words = {w for h in (pat.get("hook_templates") or [])[:3]
                      for w in re.findall(r"[a-z]{5,}", str(h).lower())
                      if w not in STOPWORDS}
        topics = []
        for t in _title_templates(seeds, pat):
            words = {w.lower() for w in re.findall(r"[a-z]{4,}", t)}
            score = 0
            why = []
            kw_hit = niche_kw & words
            if kw_hit:
                score += 2
                why.append(f"niche keywords: {', '.join(sorted(kw_hit)[:3])}")
            if re.search(r"\d", t):
                score += 2
                why.append("number in title")
            if re.search(r"[\(\[]", t):
                score += 2
                why.append("bracket tag")
            if hook_words & words:
                score += 2
                why.append("hook-template match")
            if 40 <= len(t) <= 70:
                score += 1
                why.append("length 40–70")
            if "?" in t or "—" in t:
                score += 1
                why.append("curiosity marker")
            topics.append({"title": t, "topic": t,
                           "score": min(10, score),
                           "why": "; ".join(why) or "formula fit"})
        topics.sort(key=lambda d: d["score"], reverse=True)
        return topics
    except Exception:  # noqa: BLE001
        return []


# ---------------------------------------------------------------- study note

def save_study_note(path, meta, mechanics, topics):
    """Write the study as markdown: title + mechanics + topics.

    Returns True on success. Never raises.
    """
    try:
        m = meta or {}
        mc = mechanics or {}
        tf = mc.get("title_formula") or {}
        td = mc.get("description") or {}
        lines = [
            f"# Study — {(m.get('title') or 'untitled')}",
            "",
            f"- URL: {m.get('url', '')}",
            f"- Author: {m.get('author', '')}",
            (f"- Views: {int(m.get('views') or 0):,}  "
             f"· Published: {m.get('published') or 'n/a'}"),
            "",
            "## Title formula (decoded, never copied)",
            "",
            f"- length: {tf.get('length', 0)} chars · case: {tf.get('case', '')}",
            f"- numbers: {', '.join(tf.get('numbers') or []) or 'none'}",
            (f"- bracket tags: "
             f"{', '.join(tf.get('bracket_tags') or []) or 'none'}"),
            f"- questions: {tf.get('questions', 0)} · "
            f"exclamations: {tf.get('exclamations', 0)}",
            "",
            "## Thumbnail formula",
            "",
            f"- size: {mc.get('thumbnail', {}).get('size') or 'n/a'} · "
            f"brightness: {mc.get('thumbnail', {}).get('brightness') or 'n/a'}",
            (f"- dominant colors: "
             f"{', '.join(mc.get('thumbnail', {}).get('dominant_colors') or []) or 'n/a'}"),
            "",
            "## Description CTA order",
            "",
            f"- line order: {' → '.join(td.get('cta_order') or []) or 'n/a'}",
            (f"- disclosure present: "
             f"{'yes' if td.get('has_disclosure') else 'no'}"),
            "",
            "## Hook",
            "",
            f"> {mc.get('hook') or 'n/a'}",
            "",
            "## Chapters found",
            "",
        ]
        chaps = mc.get("chapters") or []
        if chaps:
            lines += [f"- {c.get('ts')} — {c.get('label')}" for c in chaps]
        else:
            lines.append("- none detected in description")
        lines += ["", "## Generated topics (scored vs channel Pattern)",
                  ""]
        for i, t in enumerate(topics or [], 1):
            lines.append(f"{i}. **{t.get('title', '')}** "
                         f"(score {t.get('score', 0)}/10)")
            lines.append(f"   - why: {t.get('why', '')}")
        Path(path).parent.mkdir(parents=True, exist_ok=True)
        Path(path).write_text("\n".join(lines) + "\n", encoding="utf-8")
        return True
    except Exception:  # noqa: BLE001
        return False
