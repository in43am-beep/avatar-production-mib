"""mib/prompts.py — user-specified prompt builders.

viral_titles: the 20-viral-titles generator (his VIDEO TOPIC prompt).
amish_script: the Amish storyteller script mode (his VIDEO SCRIPT PROMPT).
thumbnail: the locked-character thumbnail prompt template.

All builders are pure functions (no network, no keys) so the UI can
show the prompt text in a copy-paste dialog when no LLM key is
configured — the free/local fallback.
"""
from . import viral_titles, amish_script, thumbnail

__all__ = ["viral_titles", "amish_script", "thumbnail"]
