"""mib/prompts/amish_script.py — AMISH STORYTELLER script mode.

Implements the user's VIDEO SCRIPT PROMPT verbatim in spirit:
persona = Amish farmer Elias Yoder, shocking pain-point hook,
ancestral knowledge, hidden secrets, industry-sceptic angle,
curiosity loops, continuous voice-over narration, no bullet points.

Pure functions — no network, no keys. section_word_counts() scales
the 8 sections proportionally so total words hit
target_minutes * WPM within +-10%.
"""
import re

PERSONA_NAME = "Elias Yoder"
WPM = 130

# (section name, base min words, base max words) — midpoints sum to 7150
# words, i.e. ~55 minutes at 130 wpm; scaled proportionally per target.
SECTIONS = [
    ("HOOK", 300, 500),
    ("AUTHORITY + STORY", 500, 1000),
    ("THE HIDDEN SECRET", 1000, 2000),
    ("WHY MODERN PEOPLE GOT IT WRONG", 1000, 1500),
    ("STEP-BY-STEP METHOD", 1000, 2000),
    ("COMMON MISTAKES", 500, 1000),
    ("FINAL LESSON", 500, 1000),
    ("NEXT VIDEO TEASER", 200, 300),
]

CURIOSITY_LOOPS = [
    "But that's not the most important part...",
    "What happened next shocked me...",
    "Nobody talks about this anymore...",
]

BEAT_NAMES = [name for name, _a, _b in SECTIONS]


def _base_midpoints():
    return [(name, (lo + hi) // 2) for name, lo, hi in SECTIONS]


def section_word_counts(target_minutes, wpm=WPM):
    """Scale the 8 sections proportionally to the target length.

    Returns [(section_name, words)]. Total lands within +-10% of
    target_minutes * wpm. Never raises.
    """
    try:
        minutes = max(1, int(target_minutes or 5))
    except (TypeError, ValueError):
        minutes = 5
    try:
        wpm = max(60, int(wpm or WPM))
    except (TypeError, ValueError):
        wpm = WPM
    base = _base_midpoints()
    base_total = sum(w for _, w in base)
    target = minutes * wpm
    try:
        out, acc = [], 0
        for i, (name, bw) in enumerate(base):
            if i < len(base) - 1:
                w = max(20, round(bw * target / base_total))
                out.append((name, w))
                acc += w
            else:
                out.append((name, max(20, target - acc)))
        return out
    except Exception:  # noqa: BLE001
        return [(name, max(20, (minutes * wpm) // len(base)))
                for name, _ in base]


def build_prompt(title, target_minutes=5, channel_name=""):
    """Build the full Amish-storyteller script prompt. Never raises."""
    try:
        minutes = max(1, int(target_minutes or 5))
    except (TypeError, ValueError):
        minutes = 5
    try:
        counts = section_word_counts(minutes)
        total = sum(w for _, w in counts)
        struct_lines = "\n".join(
            f"- {name} ({w} words)" for name, w in counts)
        ch = (f" for the YouTube channel '{channel_name}'"
              if channel_name else "")
        loops = "\n".join(f'- "{p}"' for p in CURIOSITY_LOOPS)
        return (
            "You are an elite YouTube scriptwriter specialising in viral "
            "Amish-style DIY, homesteading, survival, gardening, "
            "pest-control, and money-saving videos.\n"
            f'Create a long-form YouTube script{ch} about:\n'
            f'TOPIC: {title}\n'
            f"TARGET LENGTH: about {total} words "
            f"(~{minutes} minutes of narration).\n"
            "\n"
            "Write in the storytelling voice of an Amish farmer named "
            f"{PERSONA_NAME}.\n"
            "\n"
            "SCRIPT REQUIREMENTS:\n"
            "- Start with a shocking pain point.\n"
            "- Create immediate curiosity.\n"
            f"- Introduce {PERSONA_NAME} and his Amish background.\n"
            "- Mention knowledge passed down from his grandfather, "
            "mother, or ancestors.\n"
            "- Present a hidden secret that modern people don't know.\n"
            "- Suggest that industries profit from people not knowing "
            "this information.\n"
            "- Use emotional storytelling and personal anecdotes.\n"
            "- Explain the solution in simple language.\n"
            "- Include practical step-by-step instructions.\n"
            "- Frequently create curiosity loops, for example:\n"
            f"{loops}\n"
            "- Use conversational language.\n"
            "- Avoid scientific jargon unless explained simply.\n"
            "- Make the solution sound inexpensive and achievable.\n"
            "- Include at least 3 personal stories.\n"
            "- Include at least 2 examples from neighbours or community "
            "members.\n"
            "- Create a strong emotional connection with self-reliance "
            "and traditional wisdom.\n"
            "- End with a teaser for the next video.\n"
            "- NEVER use bullet points inside the script.\n"
            "- Write as a continuous narration suitable for voice-over.\n"
            "- Maintain high audience retention with a curiosity beat "
            "every 30-60 seconds.\n"
            "\n"
            "SCRIPT STRUCTURE (word counts are targets, stay close):\n"
            f"{struct_lines}\n"
            "\n"
            "Tone: warm, confident, old-fashioned, practical, slightly "
            "controversial, highly engaging.\n"
            "\n"
            "Return JSON ONLY with keys: "
            '{"hook": "<the HOOK section, continuous narration>", '
            '"beats": [{"name": "<section name>", "narration": "<that '
            'section, continuous narration>", "image_prompt": '
            '"<photorealistic cinematic 16:9 scene, no text, no watermark>"} '
            "... one beat per section in order ...], "
            '"cta": "<warm subscribe ask + the NEXT VIDEO TEASER, '
            'continuous narration>"}. '
            "The narration fields TOGETHER are the complete script — "
            "continuous voice-over text only: no headers, no stage "
            "directions, no bracketed cues, no bullet points, no markdown."
        )
    except Exception:  # noqa: BLE001
        return ""


def plain_text_prompt(title, target_minutes=5, channel_name=""):
    """Copy-paste variant: the same prompt, asking for the raw script
    instead of JSON (for the no-key fallback dialog). Never raises."""
    try:
        p = build_prompt(title, target_minutes, channel_name)
        p = re.sub(
            r'Return JSON ONLY with keys: .*?no markdown\.',
            "Output only the final script — the complete continuous "
            "narration, nothing else.",
            p, flags=re.S)
        return p
    except Exception:  # noqa: BLE001
        return ""
