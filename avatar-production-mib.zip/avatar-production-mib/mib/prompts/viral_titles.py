"""mib/prompts/viral_titles.py — the VIRAL TITLE GENERATOR.

Implements the user's VIDEO TOPIC prompt verbatim in spirit:
20 YouTube title ideas (100K-1M+ view potential) for the DIY /
homesteading / money-saving audience, ranked strongest-first.

Pure functions — no network, no keys. The UI calls build_prompt()
and either sends it to the script-LLM pool or shows it in a
copy-paste dialog (free/local fallback).
"""
import re

AUDIENCES = [
    "Homeowners",
    "Gardeners",
    "Homesteaders",
    "Off-grid enthusiasts",
    "DIY hobbyists",
    "People looking to save money",
]

CATEGORIES = [
    "Pest control",
    "Cooling homes naturally",
    "Weed removal",
    "Rodent control",
    "Snake prevention",
    "Water harvesting",
    "Food preservation",
    "Gardening secrets",
    "Amish methods",
    "Forgotten old farmer tricks",
    "Emergency preparedness",
    "Solar and off-grid living",
    "Household cleaning hacks",
    "Wood preservation",
    "Natural fertilizers",
]

STRUCTURES = [
    "The $3 Trick That...",
    "The Ancient Method That...",
    "Why the Amish Never...",
    "Kill Every...",
    "Stop Buying...",
    "The Forgotten Secret...",
    "Nobody Knows This About...",
    "How To Get [Result] Without [Costly Thing]",
]

TITLE_COUNT = 20


def build_prompt(channel_name="", niche=""):
    """Build the full title-generator prompt. Never raises."""
    try:
        ch = f' for the YouTube channel "{channel_name}"' if channel_name else ""
        nz = (f" Channel niche/context: {niche}."
              if niche else "")
        audiences = "\n".join(f"- {a}" for a in AUDIENCES)
        categories = "\n".join(f"- {c}" for c in CATEGORIES)
        structures = "\n".join(f'- "{s}"' for s in STRUCTURES)
        return (
            "Act as a YouTube strategist who has analysed 10,000+ viral "
            "DIY and homesteading videos.\n"
            f"Generate {TITLE_COUNT} YouTube title ideas{ch} that could "
            "realistically get 100K-1M+ views.\n"
            f"{nz}\n"
            "Audience:\n"
            f"{audiences}\n"
            "Prioritise these categories:\n"
            f"{categories}\n"
            "Use proven viral title structures such as:\n"
            f"{structures}\n"
            "Make every title feel:\n"
            "- Highly useful\n"
            "- Easy to understand\n"
            "- Curiosity-driven\n"
            "- Specific\n"
            "- Practical\n"
            "Rules: titles must be original — never copy any existing "
            "video's title. Keep each title under 70 characters.\n"
            "Output: first list the 20 titles numbered 1-20, then at the "
            "end rank the top 20 strongest ideas strongest-first under a "
            '"RANKED TOP 20" heading.'
        )
    except Exception:  # noqa: BLE001
        return ""


def parse_titles(text):
    """Extract up to 20 titles from numbered LLM output lines.

    Accepts "1. Title", "1) Title", "1: Title", "**1.** Title". Strips
    markdown bold and trailing rank-section duplication. Never raises.
    """
    out = []
    try:
        for line in str(text or "").splitlines():
            line = line.strip()
            if not line or len(out) >= TITLE_COUNT:
                continue
            m = re.match(r"^(?:\*\*)?(\d{1,2})[.\)\:\-](?:\*\*)?\s+(.+)$",
                         line)
            if not m:
                continue
            n = int(m.group(1))
            if n != len(out) + 1:
                # out-of-order / rank section repeat — keep first pass only
                if n <= len(out):
                    continue
                # tolerate gaps: accept if it looks like a title
            t = m.group(2).strip().strip("*").strip()
            t = re.sub(r"\s+", " ", t)
            if t and t not in out:
                out.append(t[:120])
        return out
    except Exception:  # noqa: BLE001
        return out


def ranked_block(titles):
    """Render the RANKED TOP 20 list, strongest-first. Never raises."""
    try:
        lines = ["RANKED TOP 20 (strongest first):", ""]
        for i, t in enumerate(list(titles or [])[:TITLE_COUNT], 1):
            lines.append(f"{i}. {t}")
        return "\n".join(lines)
    except Exception:  # noqa: BLE001
        return ""


class NoKeyError(Exception):
    """Raised when title generation needs an LLM key but none is set.

    Carries the ready-to-paste prompt text so the UI can show the
    copy-paste fallback dialog instead.
    """

    def __init__(self, prompt_text):
        super().__init__("No script-LLM key configured.")
        self.prompt_text = prompt_text


def generate(call_llm, channel_name="", niche=""):
    """Generate 20 titles via call_llm(prompt)->str.

    Returns (titles, raw_text). Raises NoKeyError / Exception from the
    caller on failure. Never returns a partial silent result: empty
    parse -> raises ValueError with the raw text attached.
    """
    prompt = build_prompt(channel_name, niche)
    raw = call_llm(prompt)
    titles = parse_titles(raw)
    if not titles:
        raise ValueError("The LLM returned no numbered titles. Raw "
                         "output:\n" + str(raw)[:500])
    return titles[:TITLE_COUNT], raw
