"""mib/providers/heygen.py — HeyGen talking-head avatar video client.

Documented API (verified 2026-09-25 from HeyGen developer docs + docs.rs):
  Base: https://api.heygen.com
  Auth: header "x-api-key: <KEY>" on every request.

  POST /v2/video/generate
      body: {video_inputs: [{character: {type: "avatar", avatar_id,
             avatar_style}, voice: {type: "text", input_text, voice_id?}}],
             dimension: {width, height}}
      -> {"data": {"video_id": ...}} (async generation)

  GET /v1/video_status.get?video_id=...
      -> {"data": {"status": "pending"|"processing"|"completed"|"failed",
                   "video_url": ...}}

  GET /v2/avatars -> {"data": {"avatars": [{avatar_id, avatar_name, gender,
      preview_image_url, ...}]}}   (also "talking_photos")

  GET /v2/voices -> voice list

  GET /v2/user/remaining_quota -> {"data": {"remaining_quota": N, ...}}
      (some doc versions quote quota in seconds — we normalize flexibly)

Credit cost (ESTIMATES — verify on your HeyGen plan):
  Avatar III  ~1 credit/min ; Avatar IV ~4 credits/min. The user's plan
  decides the $/credit rate. All estimates are labelled as such and the
  pipeline ALWAYS shows the estimate before spending.

Paid and strictly opt-in: nothing in the app touches HeyGen unless the
user enables it (Settings -> Channels -> HeyGen) AND pastes a key
(API Keys tab -> heygen). Without keys the avatar stage falls back to
the free custom presenter mechanics.

Never crashes the pipeline: callers catch HeyGenError and fall back.
"""
import time

import requests

from .. import costs
from ..keypool import (KeyExhausted as _KeyExhausted,
                       KeyRejected as _KeyRejected)

BASE = "https://api.heygen.com"

# ESTIMATED credit consumption per engine (verify against your plan).
ENGINES = {
    "avatar3": {"label": "Avatar III (~1 credit/min)",
                "credits_per_min": 1.0},
    "avatar4": {"label": "Avatar IV (~4 credits/min)",
                "credits_per_min": 4.0},
}
DEFAULT_ENGINE = "avatar3"

# ESTIMATE: $1.00 / credit for the Avatar III tier (docs quote ~$1/min).
CREDIT_USD_EST = 1.0


class HeyGenError(Exception):
    """Clean, UI-safe error (no tracebacks leak to the user)."""


class HeyGenExhausted(_KeyExhausted, HeyGenError):
    """429: the KeyPool rotates to the next key."""


class HeyGenRejected(_KeyRejected, HeyGenError):
    """401/403 (bad key) or 402 (insufficient credits): the KeyPool parks
    this key and tries the next."""


def _headers(api_key):
    key = (api_key or "").strip()
    if not key:
        raise HeyGenError(
            "HeyGen API key is empty. Paste it in Settings → API Keys "
            "(heygen — opt-in).")
    return {"x-api-key": key, "accept": "application/json",
            "content-type": "application/json"}


def _raise(resp):
    if resp.status_code == 429:
        raise HeyGenExhausted("HeyGen rate limit — trying next key.")
    if resp.status_code in (401, 403):
        raise HeyGenRejected(f"HeyGen refused this key "
                             f"(HTTP {resp.status_code}) — trying next key.")
    if resp.status_code == 402:
        raise HeyGenRejected("HeyGen: insufficient credits on this key — "
                             "top up in HeyGen Settings → API.")


def _clean_error(resp):
    try:
        body = resp.json()
    except Exception:  # noqa: BLE001
        body = None
    if isinstance(body, dict):
        for k in ("message", "error", "msg"):
            v = body.get(k)
            if v:
                return f"{resp.status_code}: {v}"[:300]
    return f"HeyGen HTTP {resp.status_code}: {(resp.text or '')[:200]}"


def _data(body):
    if isinstance(body, dict):
        d = body.get("data")
        return d if isinstance(d, (dict, list)) else {}
    return {}


def get_quota(api_key, timeout=20):
    """Return remaining credit balance (float) via /v2/user/remaining_quota.

    Used by Settings → API Keys → Verify. Raises HeyGenError with a
    UI-safe message.
    """
    heads = _headers(api_key)
    try:
        resp = requests.get(f"{BASE}/v2/user/remaining_quota",
                            headers=heads, timeout=timeout)
    except requests.RequestException as e:
        raise HeyGenError(f"Network error reaching HeyGen: {e}") from e
    _raise(resp)
    if resp.status_code != 200:
        raise HeyGenError(_clean_error(resp))
    try:
        data = _data(resp.json())
    except Exception as e:  # noqa: BLE001
        raise HeyGenError(f"Unexpected HeyGen quota response: {e}") from e
    if not isinstance(data, dict):
        data = {}
    for k in ("remaining_quota", "quota", "balance", "credits"):
        v = data.get(k)
        if isinstance(v, (int, float)):
            return float(v)
    # some shapes nest under details / api
    det = data.get("details")
    if isinstance(det, dict):
        for k in ("api", "remaining_quota", "credits"):
            v = det.get(k)
            if isinstance(v, (int, float)):
                return float(v)
    raise HeyGenError("Could not read remaining credits from the response.")


def list_avatars(api_key, timeout=30):
    """Return [{avatar_id, avatar_name, gender, preview_image_url}]."""
    heads = _headers(api_key)
    try:
        resp = requests.get(f"{BASE}/v2/avatars", headers=heads,
                            timeout=timeout)
    except requests.RequestException as e:
        raise HeyGenError(f"Network error reaching HeyGen: {e}") from e
    _raise(resp)
    if resp.status_code != 200:
        raise HeyGenError(_clean_error(resp))
    try:
        data = _data(resp.json())
    except Exception as e:  # noqa: BLE001
        raise HeyGenError(f"Unexpected HeyGen avatars response: {e}") from e
    raw = []
    if isinstance(data, dict):
        raw = (data.get("avatars") or []) + (data.get("talking_photos") or [])
    elif isinstance(data, list):
        raw = data
    out = []
    for r in raw:
        if not isinstance(r, dict):
            continue
        aid = (r.get("avatar_id") or r.get("talking_photo_id")
               or r.get("id") or "")
        if not aid:
            continue
        out.append({
            "avatar_id": str(aid),
            "avatar_name": str(r.get("avatar_name")
                               or r.get("name") or aid),
            "gender": str(r.get("gender") or ""),
            "preview_image_url": str(r.get("preview_image_url")
                                     or r.get("preview_image") or ""),
        })
    return out


def estimate_credits(duration_s, engine=DEFAULT_ENGINE):
    """ESTIMATED HeyGen credits for a video of duration_s. Returns float.

    Pure function — unit-testable. Engines come from ENGINES (unknown
    engine -> default).
    """
    try:
        rate = ENGINES.get(str(engine or DEFAULT_ENGINE),
                           ENGINES[DEFAULT_ENGINE])["credits_per_min"]
        mins = max(0.0, float(duration_s or 0)) / 60.0
        return round(mins * rate, 2)
    except Exception:  # noqa: BLE001
        return 0.0


def estimate_usd(credits):
    """ESTIMATED USD for N credits (Avatar-III ~$1/credit)."""
    try:
        return round(float(credits or 0) * CREDIT_USD_EST, 2)
    except Exception:  # noqa: BLE001
        return 0.0


def _request_video(api_key, avatar_id, text, voice_id="", engine="avatar3",
                   width=1920, height=1080, timeout=60):
    """POST /v2/video/generate -> video_id. Raises HeyGenError."""
    heads = _headers(api_key)
    avatar_id = (avatar_id or "").strip()
    if not avatar_id:
        raise HeyGenError("No HeyGen avatar id set. Pick one in "
                          "Settings → Channels → HeyGen.")
    text = (text or "").strip()
    if not text:
        raise HeyGenError("Script text is empty — nothing to speak.")
    character = {"type": "avatar", "avatar_id": avatar_id,
                 "avatar_style": "normal"}
    voice = {"type": "text", "input_text": text}
    if (voice_id or "").strip():
        voice["voice_id"] = voice_id.strip()
    body = {"video_inputs": [{"character": character, "voice": voice}],
            "dimension": {"width": int(width), "height": int(height)}}
    try:
        resp = requests.post(f"{BASE}/v2/video/generate", headers=heads,
                             json=body, timeout=timeout)
    except requests.RequestException as e:
        raise HeyGenError(f"Network error reaching HeyGen: {e}") from e
    _raise(resp)
    if resp.status_code != 200:
        raise HeyGenError(_clean_error(resp))
    try:
        vid = _data(resp.json()).get("video_id")
    except Exception as e:  # noqa: BLE001
        raise HeyGenError(f"Unexpected HeyGen generate response: {e}") from e
    if not vid:
        raise HeyGenError("HeyGen did not return a video_id.")
    return str(vid)


def _poll_status(api_key, video_id, poll_interval=15, timeout=5400):
    """Poll /v1/video_status.get until completed. Returns video_url."""
    heads = _headers(api_key)
    deadline = time.time() + timeout
    while True:
        if time.time() > deadline:
            raise HeyGenError("Timed out waiting for the HeyGen render — "
                              "check the video in your HeyGen dashboard.")
        time.sleep(max(5, poll_interval))
        try:
            resp = requests.get(
                f"{BASE}/v1/video_status.get?video_id={video_id}",
                headers=heads, timeout=30)
        except requests.RequestException as e:
            raise HeyGenError(f"Status poll failed: {e}") from e
        _raise(resp)
        if resp.status_code != 200:
            raise HeyGenError(_clean_error(resp))
        try:
            data = _data(resp.json())
        except Exception:  # noqa: BLE001
            continue
        status = str(data.get("status") or "").lower()
        if status == "completed":
            url = data.get("video_url") or data.get("download_url")
            if not url:
                raise HeyGenError("HeyGen finished but gave no video URL.")
            return str(url)
        if status in ("failed", "error"):
            err = data.get("error") or data.get("msg") or "render failed"
            raise HeyGenError(f"HeyGen render failed: {err}"[:300])
        # pending / processing / waiting -> keep polling


def download_video(video_url, dest_path, timeout=600):
    """Download the rendered mp4 -> dest_path. Returns the path str."""
    try:
        resp = requests.get(video_url, timeout=timeout, stream=True)
    except requests.RequestException as e:
        raise HeyGenError(f"Download failed: {e}") from e
    if resp.status_code != 200 or not resp.content:
        raise HeyGenError(f"Download failed (HTTP {resp.status_code}).")
    try:
        with open(dest_path, "wb") as f:
            for chunk in resp.iter_content(65536):
                if chunk:
                    f.write(chunk)
    except requests.RequestException as e:
        raise HeyGenError(f"Download failed: {e}") from e
    return str(dest_path)


def generate_video(api_key, avatar_id, text, voice_id="",
                   engine=DEFAULT_ENGINE, width=1920, height=1080,
                   poll_interval=15, timeout=5400, logger=None):
    """Full flow: request -> poll -> video_url.

    Returns {"video_id", "video_url", "est_credits"}. The caller downloads
    and logs the cost. Raises HeyGenError (KeyPool rotates on 429/401/402).
    """
    if logger:
        try:
            logger.log("    heygen: requesting talking-head render…")
        except Exception:  # noqa: BLE001
            pass
    vid = _request_video(api_key, avatar_id, text, voice_id, engine,
                         width, height)
    if logger:
        try:
            logger.log(f"    heygen: render queued (video_id {vid}) — "
                       "polling for completion…")
        except Exception:  # noqa: BLE001
            pass
    url = _poll_status(api_key, vid, poll_interval, timeout)
    if logger:
        try:
            logger.log("    heygen: render complete — downloading…")
        except Exception:  # noqa: BLE001
            pass
    return {"video_id": vid, "video_url": url}
