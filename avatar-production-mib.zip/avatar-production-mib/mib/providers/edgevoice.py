"""mib/providers/edgevoice.py — FREE default voiceover via edge-tts.

No API key. Needs internet. Speed 85 ~= rate "-15%".
Any failure raises EdgeError with a UI-safe message; the voiceover stage
catches it and falls back to a local silent-tone track so the pipeline
never dies on a provider failure.
"""
import asyncio
import re

try:
    import edge_tts
except Exception:  # noqa: BLE001
    edge_tts = None


class EdgeError(Exception):
    """Clean, UI-safe error."""


DEFAULT_FEMALE = "en-US-AvaNeural"    # warm female
DEFAULT_MALE = "en-US-AndrewNeural"   # male


def _rate_for_speed85():
    return "-15%"


def _clean_text(text):
    """Edge-tts chokes on some control chars; strip them."""
    t = str(text or "")
    t = re.sub(r"[\x00-\x08\x0b\x0c\x0e-\x1f]", " ", t)
    return t.strip()


async def _speak_async(text, voice, rate, out_path):
    comm = edge_tts.Communicate(_clean_text(text), voice, rate=rate)
    await comm.save(str(out_path))


def synthesize(text, voice, out_path, rate=None, timeout=300):
    """Synthesize text -> mp3 file. Raises EdgeError on any failure."""
    if edge_tts is None:
        raise EdgeError("edge-tts is not installed (pip install edge-tts).")
    text = _clean_text(text)
    if not text:
        raise EdgeError("Script text is empty — nothing to speak.")
    voice = (voice or "").strip() or DEFAULT_FEMALE
    rate = rate or _rate_for_speed85()
    try:
        asyncio.run(asyncio.wait_for(
            _speak_async(text, voice, rate, out_path), timeout=timeout))
    except asyncio.TimeoutError as e:
        raise EdgeError("Edge TTS timed out (network slow?).") from e
    except Exception as e:  # noqa: BLE001
        raise EdgeError(f"Edge TTS failed: {e}"[:300]) from e
    return str(out_path)


def list_voices(timeout=30):
    """Return [{id, name, gender, locale}] for English voices. UI-safe."""
    if edge_tts is None:
        return []
    try:
        async def _go():
            return await edge_tts.list_voices()
        voices = asyncio.run(asyncio.wait_for(_go(), timeout=timeout))
    except Exception:  # noqa: BLE001
        return []
    out = []
    for v in voices or []:
        locale = str(v.get("Locale", ""))
        if not locale.startswith("en"):
            continue
        out.append({
            "id": v.get("ShortName", ""),
            "name": v.get("FriendlyName", v.get("ShortName", "")),
            "gender": str(v.get("Gender", "")).lower(),
            "locale": locale,
        })
    out.sort(key=lambda v: (v["locale"], v["name"]))
    return out
