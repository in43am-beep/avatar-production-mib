"""mib/autopilot.py — fully automatic URL -> video chain.

Paste a reference YouTube video URL; the app runs the whole chain with
zero manual steps in between:

  study (fetch public metadata, decode packaging) ->
  20 viral titles (script-LLM pool) -> top-ranked title ->
  script (Amish storyteller mode) -> thumbnail prompt -> video

run_chain() is UI-free and testable: the caller injects titles_caller
and pipeline_fn. The Qt dialog (mib/ui/autopilot_dialog.py) wires the
real key pools and run_pipeline.

Free/local fallbacks: study fetch needs no key (public web requests).
Title generation needs a script-LLM key — without one, run_chain
returns {"ok": False, "prompt_text": <copy-paste prompt>} so the UI can
show the copy-paste dialog instead of failing silently.
"""
from . import study as _study
from .prompts import viral_titles as _vt


def _channel_defaults(channel):
    ch = channel or {}
    try:
        minutes = int(ch.get("default_minutes") or 5)
    except (TypeError, ValueError):
        minutes = 5
    return {
        "name": ch.get("name", ""),
        "niche": ch.get("niche", ""),
        "mode": (ch.get("mode") or "avatar").lower(),
        "minutes": max(1, minutes),
    }


def run_chain(url, channel_id, cfg, secrets, titles_caller, pipeline_fn,
              progress_cb=None, log_cb=None):
    """Run the full URL -> video chain. Never raises.

    titles_caller(prompt) -> (titles, raw_text); may raise
        viral_titles.NoKeyError (carries .prompt_text) when no LLM key
        is configured.
    pipeline_fn(title, channel_id, cfg, secrets, opts, progress_cb,
        log_cb) -> result dict (same contract as run_pipeline).

    Returns {"ok", "title", "titles", "meta", "pipeline_result",
             "error", "prompt_text"}.
    """
    def _prog(p, m):
        try:
            if progress_cb:
                progress_cb(p, m)
        except Exception:  # noqa: BLE001
            pass

    def _log(line):
        try:
            if log_cb:
                log_cb(line)
        except Exception:  # noqa: BLE001
            pass

    out = {"ok": False, "title": "", "titles": [], "meta": {},
           "pipeline_result": {}, "error": "", "prompt_text": ""}
    try:
        cfg = cfg or {}
        channel = (cfg.get("channels") or {}).get(channel_id) or {}
        dflt = _channel_defaults(channel)
        provs = cfg.get("providers") or {}

        # 1. study: fetch the reference video's public metadata
        _prog(5, "Studying the reference video…")
        _log("autopilot: fetching reference video metadata…")
        meta = _study.fetch_metadata(url)
        if not isinstance(meta, dict) or meta.get("error"):
            out["error"] = ("Study failed: "
                            + str((meta or {}).get("error")
                                   or "could not fetch the video"))
            return out
        out["meta"] = meta
        _log(f"autopilot: studying "
             f"'{(meta.get('title') or '')[:60]}' "
             f"by {meta.get('author', '')}")

        # 2. 20 viral titles via the script-LLM pool
        _prog(15, "Generating 20 viral titles…")
        _log("autopilot: generating 20 viral titles…")
        try:
            titles, _raw = titles_caller(
                _vt.build_prompt(dflt["name"], dflt["niche"]))
        except _vt.NoKeyError as e:
            out["error"] = ("No script-LLM key configured — cannot "
                            "generate titles automatically.")
            out["prompt_text"] = getattr(e, "prompt_text", "") or ""
            return out
        titles = [t for t in (titles or []) if str(t).strip()]
        if not titles:
            out["error"] = ("Title generation returned no titles — "
                            "try again or pick a title manually.")
            return out
        out["titles"] = titles[:_vt.TITLE_COUNT]
        top = out["titles"][0]
        out["title"] = top
        _log(f"autopilot: top-ranked title: {top}")

        # 3+4. pipeline with Amish storyteller script mode; the package
        # stage writes the locked-character thumbnail prompt per video.
        opts = {
            "mode": dflt["mode"],
            "minutes_override": dflt["minutes"],
            "presenter_seconds": provs.get("presenter_seconds", 6),
            "appearances": provs.get("appearances", 1),
            "script_style": "amish",
        }
        _prog(20, f"Producing: {top[:50]}…")
        _log("autopilot: running pipeline (Amish storyteller script)…")
        res = pipeline_fn(top, channel_id, cfg, secrets, opts,
                          progress_cb=lambda p, m: _prog(
                              20 + int(p * 0.8), m),
                          log_cb=_log)
        out["pipeline_result"] = res or {}
        if (res or {}).get("ok"):
            out["ok"] = True
            _log("autopilot: video finished ✓")
        else:
            out["error"] = ("Pipeline failed: "
                            + str((res or {}).get("error") or "unknown"))
        return out
    except Exception as e:  # noqa: BLE001
        out["error"] = f"Auto-pilot failed: {e}"[:300]
        return out
