"""mib/pipeline.py — orchestrates the per-title pipeline.

output/<channel>/<slug>/ per video. Stages:
  script -> voiceover -> images -> avatar -> assemble -> package -> qc

run_pipeline() NEVER raises: any failure is captured into the result dict
and the job is quarantined with a reason.
"""
import json
import re
import unicodedata
from pathlib import Path

from . import costs, qc
from .config import ROOT
from .log import JobLogger
from .stages import script as st_script
from .stages import voiceover as st_voice
from .stages import images as st_images
from .stages import avatar as st_avatar
from .stages import assemble as st_assemble
from .stages import package as st_package


def slugify(title):
    """Title -> filesystem-safe slug. Never raises."""
    try:
        t = unicodedata.normalize("NFKD", str(title or "untitled"))
        t = t.encode("ascii", "ignore").decode("ascii")
        t = re.sub(r"[^a-zA-Z0-9]+", "-", t).strip("-").lower()
        return t[:80] or "untitled"
    except Exception:  # noqa: BLE001
        return "untitled"


def _progress(cb, pct, msg):
    try:
        if cb:
            cb(pct, msg)
    except Exception:  # noqa: BLE001
        pass


def run_pipeline(title, channel_id, cfg, secrets, opts=None,
                 progress_cb=None, log_cb=None):
    """Run the full pipeline for one title.

    opts: {minutes_override, mode ("avatar"|"frontier"),
           presenter_seconds, appearances}
    Returns {"ok", "title", "job_dir", "final_mp4", "duration_s",
             "total_cost_usd", "qc_reasons", "error"}. Never raises.
    """
    opts = opts or {}
    cfg = cfg or {}
    secrets = secrets or {}
    channels = cfg.get("channels") or {}
    channel = channels.get(channel_id) or {}
    slug = slugify(title)
    job_dir = ROOT / "output" / channel_id / slug

    logger = JobLogger(job_dir, callback=log_cb)
    result = {"ok": False, "title": title, "job_dir": str(job_dir),
              "final_mp4": "", "duration_s": 0.0, "total_cost_usd": 0.0,
              "qc_reasons": [], "error": ""}

    try:
        job_dir.mkdir(parents=True, exist_ok=True)
    except Exception as e:  # noqa: BLE001
        result["error"] = f"cannot create job dir: {e}"
        return result

    costs.set_current_job_dir(job_dir)
    costs.init_job(job_dir)
    try:
        mode = (opts.get("mode")
                or channel.get("mode") or "avatar").lower()
        try:
            minutes = int(opts.get("minutes_override")
                          or channel.get("default_minutes") or 5)
        except (TypeError, ValueError):
            minutes = 5

        logger.log(f"=== {title}")
        logger.log(f"channel={channel_id} mode={mode} target={minutes}min")

        # 1. script
        _progress(progress_cb, 5, "Writing script…")
        logger.log("[1/6] script…")
        scr = None
        provs = cfg.get("providers") or {}
        if provs.get("script_provider") == "ai33pro":
            try:
                from .providers import scriptllm
                scr = scriptllm.generate(
                    title, minutes, secrets.get("ai33pro_api_key"),
                    provs.get("ai33pro_llm_base_url", ""),
                    provs.get("ai33pro_llm_model", ""))
                logger.log("    script [ai33pro-llm]")
            except Exception as e:  # noqa: BLE001
                logger.log(f"    script [ai33pro-llm] failed: {e} — "
                           "local rules fallback")
                scr = None
        if scr is None:
            scr = st_script.build_script(title, minutes, channel)
            logger.log("    script [local rules]")
        st_script.save_script(job_dir, scr)
        logger.log(f"    {scr['words']} words ≈ {scr['est_minutes']} min")

        # 2. voiceover
        _progress(progress_cb, 20, "Synthesizing voiceover…")
        logger.log("[2/6] voiceover…")
        voice = st_voice.run(job_dir, scr, channel.get("voice"),
                             secrets, logger)
        total_vo = sum(s["duration"] for s in voice["segments"])

        # 3. images
        _progress(progress_cb, 40, "Generating images…")
        logger.log("[3/6] images…")
        imgs = st_images.run(job_dir, scr, channel_id, cfg, secrets, logger)

        # 4. avatar intro
        _progress(progress_cb, 60, "Rendering presenter…")
        logger.log("[4/6] presenter…")
        avatar_res = {"intro": "", "mids": []}
        if mode == "avatar":
            presenter = _find_presenter(cfg, channel.get("presenter"))
            avatar_res = st_avatar.run(
                job_dir, voice["voiceover"], presenter,
                seconds=opts.get("presenter_seconds")
                or (cfg.get("providers") or {}).get("presenter_seconds", 6),
                appearances=opts.get("appearances")
                or (cfg.get("providers") or {}).get("appearances", 1),
                total_duration=total_vo, logger=logger)
        else:
            logger.log("    frontier mode: no presenter intro")

        # 5. assemble
        _progress(progress_cb, 78, "Assembling video…")
        logger.log("[5/6] assemble…")
        final, duration = st_assemble.run(
            job_dir, voice["segments"], imgs, avatar_res, logger,
            subtitles=bool(channel.get("subtitles")),
            script=scr)
        result["final_mp4"] = final
        result["duration_s"] = duration

        # 6. package
        _progress(progress_cb, 90, "Packaging…")
        logger.log("[6/6] package…")
        st_package.run(job_dir, scr, channel, final, duration,
                       {"voice": voice["provider"],
                        "mode": mode,
                        "presenter": avatar_res.get("presenter", "")},
                       logger)

        # 7. qc
        _progress(progress_cb, 96, "Quality check…")
        ok, reasons = qc.check(final, scr["est_minutes"])
        result["qc_reasons"] = reasons
        if ok:
            qc.mark_passed(job_dir)
            result["ok"] = True
            logger.log(f"QC PASSED ({duration:.0f}s)")
        else:
            qc.quarantine(job_dir, reasons)
            result["error"] = "; ".join(reasons)
            logger.log(f"QC FAILED → quarantine: {result['error']}")

        result["total_cost_usd"] = costs.job_cost(job_dir)["total_usd"]
        _progress(progress_cb, 100,
                  "Done" if result["ok"] else "Failed (quarantined)")
        return result
    except Exception as e:  # noqa: BLE001
        msg = f"pipeline crashed: {e}"
        logger.log(msg)
        try:
            qc.quarantine(job_dir, [msg])
        except Exception:  # noqa: BLE001
            pass
        result["error"] = msg[:500]
        result["total_cost_usd"] = costs.job_cost(job_dir)["total_usd"]
        _progress(progress_cb, 100, "Failed (quarantined)")
        return result
    finally:
        costs.clear_current_job_dir()


def _find_presenter(cfg, presenter_id):
    for p in cfg.get("presenters") or []:
        if p.get("id") == presenter_id:
            return p
    presenters = cfg.get("presenters") or []
    return presenters[0] if presenters else {}
