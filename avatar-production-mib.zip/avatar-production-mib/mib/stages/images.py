"""mib/stages/images.py — per-beat scene images.

Order: user's own PC images (when enabled for the channel) -> grok ->
gemini -> free local. PC images are cycled in alphabetical order when there
are more scenes than images.
"""
import shutil
from pathlib import Path

from ..providers import genimages


def run(job_dir, script, channel_id, cfg, secrets, logger=None):
    """Generate images/scene-NN.png (1920x1080). Returns [paths]. Never raises."""
    job = Path(job_dir)
    img_dir = job / "images"
    try:
        img_dir.mkdir(parents=True, exist_ok=True)
    except Exception:  # noqa: BLE001
        pass

    title = script.get("title", "")
    # hook + beats + cta each get a scene image
    items = [("hook", script.get("hook", ""), "Opening scene. ")]
    for i, b in enumerate(script.get("beats", [])):
        items.append((b.get("name", f"beat-{i}"), b.get("narration", ""),
                      b.get("image_prompt", "")))
    items.append(("cta", script.get("cta", ""),
                  "Warm closing scene, hopeful light. "))

    pool = genimages.local_pool(cfg, channel_id)
    if pool and logger:
        try:
            logger.log(f"    image [pc-upload]: {len(pool)} PC image(s) "
                       f"for channel '{channel_id}' — cycling in order")
        except Exception:  # noqa: BLE001
            pass

    paths = []
    for idx, (beat_name, _txt, img_prompt) in enumerate(items):
        out = img_dir / f"scene-{idx:02d}.png"
        if pool:
            try:
                src = pool[idx % len(pool)]
                shutil.copy(str(src), str(out))
                genimages.fit_1920x1080(out)
                if logger:
                    logger.log(f"    image [pc-upload]: {src.name}"
                               f" -> {out.name}")
                paths.append(str(out))
                continue
            except Exception:  # noqa: BLE001
                pass  # fall through to AI providers
        prompt = img_prompt or f"Cinematic scene for: {title}."
        try:
            path, _prov = genimages.make_image(
                prompt, title, beat_name, out, secrets, cfg,
                logger=logger, seed=idx)
        except Exception:  # noqa: BLE001
            try:
                path = genimages.generate_local(title, beat_name, out,
                                                seed=idx)
            except Exception:  # noqa: BLE001
                from PIL import Image
                Image.new("RGB", (1920, 1080), (20, 22, 28)).save(out, "PNG")
                path = str(out)
        paths.append(str(path))
    return paths
