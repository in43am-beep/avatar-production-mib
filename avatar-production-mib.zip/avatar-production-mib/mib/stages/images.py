"""mib/stages/images.py — per-beat scene images (grok -> gemini -> local)."""
from pathlib import Path

from ..providers import genimages


def run(job_dir, script, cfg, secrets, logger=None):
    """Generate images/scene-NN.png (1920x1080). Returns [paths]. Never raises."""
    job = Path(job_dir)
    img_dir = job / "images"
    try:
        img_dir.mkdir(parents=True, exist_ok=True)
    except Exception:  # noqa: BLE001
        pass

    title = script.get("title", "")
    # hook + beats + cta each get a scene image
    items = [("hook", script.get("hook", ""), "Opening scene. ")]
    for i, b in enumerate(script.get("beats", [])):
        items.append((b.get("name", f"beat-{i}"), b.get("narration", ""),
                      b.get("image_prompt", "")))
    items.append(("cta", script.get("cta", ""),
                  "Warm closing scene, hopeful light. "))

    paths = []
    for idx, (beat_name, _txt, img_prompt) in enumerate(items):
        out = img_dir / f"scene-{idx:02d}.png"
        prompt = img_prompt or f"Cinematic scene for: {title}."
        try:
            path, _prov = genimages.make_image(
                prompt, title, beat_name, out, secrets, cfg,
                logger=logger, seed=idx)
        except Exception:  # noqa: BLE001
            try:
                path = genimages.generate_local(title, beat_name, out,
                                                seed=idx)
            except Exception:  # noqa: BLE001
                from PIL import Image
                Image.new("RGB", (1920, 1080), (20, 22, 28)).save(out, "PNG")
                path = str(out)
        paths.append(str(path))
    return paths
