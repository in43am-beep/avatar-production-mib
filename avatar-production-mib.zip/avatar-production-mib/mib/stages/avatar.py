"""mib/stages/avatar.py — presenter clips in the reference style.

Decoded from the frame-by-frame study of the reference video
(Elias Gardener, "The Secret Liquid That Melts Leaves Into Compost in
Just Days!", 22:11):

- Cold open: the video starts IMMEDIATELY on a full-screen tight face
  close-up of the presenter (no title card, no ident). The hook line
  begins at 0:00.
- Chapter openings get LONG presenter-led segments (30-70s): they open
  full-screen close-up, then cut to a 50/50 SPLIT-SCREEN with the
  presenter on the RIGHT and B-roll on the LEFT.
- Mid-chapter beats get SHORT split-screen interludes (~5-10s).
- The presenter returns roughly every 1-3 minutes; every appearance
  speaks NEW, continuing script (never repeats a line).
- ALL transitions between presenter shots are hard cuts — no fades,
  dissolves or slides.
- The presenter "set" is one static room; framing is a tight face
  close-up both full-screen and in the split-screen right half.

Never raises.
"""
from pathlib import Path

from .. import costs
from .. import ffmpeg

# reference-derived timing constants
CHAPTER_MAX_S = 45.0    # chapter segments never run longer than this
CHAPTER_CLOSEUP_S = 12.0  # full-screen close-up opens each chapter segment
INTERLUDE_S = 7.0       # short mid-chapter split-screen check-ins
GAP_TRIGGER_S = 110.0   # a gap this big between presenter spots gets an interlude
MIN_CHAPTER_S = 8.0     # beats shorter than this get no chapter segment


def _resolve_image(presenter):
    """Presenter image path -> existing PNG, else a generated placeholder.

    Checks the writable app dir (ROOT) first, then the frozen bundle dir
    (BUNDLE_DIR) so built-in avatars resolve inside the Windows exe too.
    """
    try:
        from ..config import ROOT, BUNDLE_DIR
    except Exception:  # noqa: BLE001
        return ""
    try:
        rel = (presenter or {}).get("image") or ""
        if rel:
            for base in (ROOT, BUNDLE_DIR):
                p = base / rel
                if p.is_file():
                    return str(p)
    except Exception:  # noqa: BLE001
        pass
    # fallback: first placeholder that exists, else any png in avatars/
    try:
        for base in (ROOT, BUNDLE_DIR):
            av = base / "assets" / "avatars"
            for cand in ("maria.png", "walter.png", "priya.png"):
                if (av / cand).is_file():
                    return str(av / cand)
            pngs = sorted(av.glob("*.png"))
            if pngs:
                return str(pngs[0])
    except Exception:  # noqa: BLE001
        pass
    return ""


def _cut_video_clip(src, start, duration, out_path, logger=None):
    """Cut [start, start+duration) of video+audio from src (re-encode).

    Used for HeyGen talking-head presenter clips. Returns True on success.
    Never raises.
    """
    try:
        start, duration = max(0.0, float(start)), max(2.0, float(duration))
        rc, _so, se = ffmpeg.run([
            "-y", "-ss", f"{start:.2f}", "-t", f"{duration:.2f}",
            "-i", str(src),
            "-c:v", "libx264", "-pix_fmt", "yuv420p", "-preset", "veryfast",
            "-c:a", "aac", "-ar", "44100", "-ac", "2",
            str(out_path),
        ], timeout=600)
        ok = rc == 0 and Path(out_path).is_file()
        if not ok and logger:
            logger.log(f"    avatar: video cut failed: {(se or '')[-200:]}")
        return ok
    except Exception as e:  # noqa: BLE001
        if logger:
            logger.log(f"    avatar: video cut error: {e}")
        return False


def _narration_text(script):
    """Full spoken text: hook + all beats + cta. Never raises."""
    try:
        parts = [str((script or {}).get("hook") or "")]
        for b in (script or {}).get("beats") or []:
            parts.append(str(b.get("narration") or ""))
        parts.append(str((script or {}).get("cta") or ""))
        return " ".join(p for p in parts if p).strip()
    except Exception:  # noqa: BLE001
        return ""


def _heygen_full_video(job_dir, script, heygen_cfg, logger=None):
    """Render the whole narration as one HeyGen talking-head video.

    heygen_cfg: {"pool", "avatar_id", "voice_id", "engine"}.
    Returns (mp4_path, est_credits) or ("", 0.0). Never raises — the
    caller falls back to the free custom presenter mechanics.
    """
    job = Path(job_dir)
    try:
        (job / "avatar").mkdir(parents=True, exist_ok=True)
    except Exception:  # noqa: BLE001
        pass
    try:
        from ..providers import heygen as _hg
    except Exception as e:  # noqa: BLE001
        if logger:
            logger.log(f"    heygen: provider module missing ({e}) — "
                       "falling back to local presenter")
        return "", 0.0
    pool = heygen_cfg.get("pool")
    avatar_id = (heygen_cfg.get("avatar_id") or "").strip()
    if pool is None:
        if logger:
            logger.log("    heygen: enabled but NO API key — falling back "
                       "to local presenter clips (add a key in Settings → "
                       "API Keys → heygen)")
        return "", 0.0
    if not avatar_id:
        if logger:
            logger.log("    heygen: enabled but no avatar id set — falling "
                       "back to local presenter clips (Settings → Channels "
                       "→ HeyGen → avatar id)")
        return "", 0.0
    text = _narration_text(script)
    if not text:
        if logger:
            logger.log("    heygen: empty script — falling back")
        return "", 0.0
    engine = heygen_cfg.get("engine") or _hg.DEFAULT_ENGINE
    voice_id = (heygen_cfg.get("voice_id") or "").strip()
    dest = job / "avatar" / "heygen-full.mp4"
    est_credits = _hg.estimate_credits(len(text.split()) / 2.4, engine)
    # words/2.4 ≈ spoken seconds at ~145 wpm
    if logger:
        logger.log(f"    heygen: render talking-head for full script "
                   f"(~{est_credits} credits est, engine {engine}) — "
                   f"this is the ONLY paid call of the avatar stage")
    try:
        res = pool.run(
            lambda k: _hg.generate_video(
                k, avatar_id, text, voice_id=voice_id, engine=engine,
                logger=logger),
            logger, op="avatar")
        url = res.get("video_url") or ""
        if not url:
            raise _hg.HeyGenError("No video URL returned.")
        _hg.download_video(url, dest)
    except Exception as e:  # noqa: BLE001
        if logger:
            logger.log(f"    heygen: render failed ({e}) — falling back "
                       "to local presenter clips")
        return "", 0.0
    # cost ledger: NEVER invisible — log the estimated credits + USD.
    try:
        costs.log_call(costs.current_job_dir() or job,
                       "heygen", "credits", est_credits,
                       note=f"heygen talking-head full script "
                            f"(engine {engine}, est)")
    except Exception:  # noqa: BLE001
        pass
    if logger:
        logger.log(f"    heygen: talking-head ready (~{est_credits} "
                   f"credits est) → {dest.name}")
    return str(dest), est_credits


def _closeup_clip(image_path, audio_path, out_path, duration, logger=None):
    """Full-screen tight face close-up (cold open / chapter openings).

    Slow push-in centred on the face (upper third), like the reference's
    forehead-to-beard framing. Returns True on success. Never raises.
    """
    try:
        duration = max(2.0, float(duration))
        rc, _so, se = ffmpeg.run([
            "-y",
            "-framerate", "30", "-loop", "1", "-t", f"{duration:.2f}",
            "-i", image_path,
            "-i", audio_path,
            "-filter_complex",
            "[0:v]scale=1920:1080:force_original_aspect_ratio=increase,"
            "crop=1920:1080,"
            "zoompan=z='min(1.30+0.0009*on,1.45)':"
            "x='iw/2-(iw/zoom/2)':y='ih*0.36-(ih/zoom/2)':"
            "d=1:s=1920x1080:fps=30[v]",
            "-map", "[v]", "-map", "1:a",
            "-c:v", "libx264", "-pix_fmt", "yuv420p", "-preset", "veryfast",
            "-c:a", "aac", "-ar", "44100", "-ac", "2",
            "-t", f"{duration:.2f}",
            str(out_path),
        ], timeout=600)
        ok = rc == 0 and Path(out_path).is_file()
        if not ok and logger:
            logger.log(f"    avatar close-up failed: {(se or '')[-200:]}")
        return ok
    except Exception as e:  # noqa: BLE001
        if logger:
            logger.log(f"    avatar close-up error: {e}")
        return False


def _split_clip(presenter_image, broll_image, audio_path, out_path,
                duration, logger=None):
    """50/50 split-screen: B-roll LEFT, presenter RIGHT (tight crop).

    Straight vertical divide, hard edges, presenter always on the right —
    the reference's only split layout. Returns True on success.
    Never raises.
    """
    try:
        duration = max(2.0, float(duration))
        rc, _so, se = ffmpeg.run([
            "-y",
            "-framerate", "30", "-loop", "1", "-t", f"{duration:.2f}",
            "-i", broll_image,
            "-framerate", "30", "-loop", "1", "-t", f"{duration:.2f}",
            "-i", presenter_image,
            "-i", audio_path,
            "-filter_complex",
            "[0:v]scale=960:1080:force_original_aspect_ratio=increase,"
            "crop=960:1080,"
            "zoompan=z='min(1+0.0007*on,1.10)':"
            "x='iw/2-(iw/zoom/2)':y='ih/2-(ih/zoom/2)':"
            "d=1:s=960x1080:fps=30[b];"
            "[1:v]scale=960:1080:force_original_aspect_ratio=increase,"
            "crop=960:1080,"
            "zoompan=z='min(1.30+0.0009*on,1.45)':"
            "x='iw/2-(iw/zoom/2)':y='ih*0.36-(ih/zoom/2)':"
            "d=1:s=960x1080:fps=30[p];"
            "[b][p]hstack=inputs=2[v]",
            "-map", "[v]", "-map", "2:a",
            "-c:v", "libx264", "-pix_fmt", "yuv420p", "-preset", "veryfast",
            "-c:a", "aac", "-ar", "44100", "-ac", "2",
            "-t", f"{duration:.2f}",
            str(out_path),
        ], timeout=600)
        ok = rc == 0 and Path(out_path).is_file()
        if not ok and logger:
            logger.log(f"    avatar split-screen failed: {(se or '')[-200:]}")
        return ok
    except Exception as e:  # noqa: BLE001
        if logger:
            logger.log(f"    avatar split-screen error: {e}")
        return False


def _concat_parts(parts, out_path, logger=None):
    """Hard-cut concat of rendered parts (stream copy). Never raises."""
    try:
        lst = Path(str(out_path) + ".txt")
        with open(lst, "w", encoding="utf-8") as f:
            for p in parts:
                f.write(f"file '{Path(p).as_posix()}'\n")
        rc, _so, se = ffmpeg.run([
            "-y", "-f", "concat", "-safe", "0", "-i", str(lst),
            "-c", "copy", str(out_path),
        ], timeout=300)
        ok = rc == 0 and Path(out_path).is_file()
        if not ok and logger:
            logger.log(f"    avatar concat failed: {(se or '')[-200:]}")
        return ok
    except Exception as e:  # noqa: BLE001
        if logger:
            logger.log(f"    avatar concat error: {e}")
        return False


def _cut_audio(src, start, duration, out_stem):
    """Cut a slice of the voiceover. Returns the output path or ''."""
    try:
        enc, out_path = ffmpeg.audio_track_args(str(out_stem))
        rc, _so, _se = ffmpeg.run([
            "-y", "-ss", f"{max(0.0, start):.2f}", "-t", f"{duration:.2f}",
            "-i", src, "-c:a", enc, "-ar", "44100", "-ac", "2",
            out_path,
        ], timeout=300)
        if rc == 0 and Path(out_path).is_file():
            return out_path
        return ""
    except Exception:  # noqa: BLE001
        return ""


def _segment_at(t, starts, durs):
    """Index of the voice segment containing voiceover-time t."""
    try:
        for i, (s, d) in enumerate(zip(starts, durs)):
            if s <= t < s + d:
                return i
        return len(starts) - 1 if starts else 0
    except Exception:  # noqa: BLE001
        return 0


def plan_segments(total, seg_starts, seg_durs, rejoin_seg_idxs,
                  seconds=6, appearances=1):
    """Decide where the presenter appears. Pure function (unit-testable).

    Returns a list of dicts, each:
      {kind: "intro"|"chapter"|"interlude", at, dur, closeup_s, seg_idx}
    - intro: cold open at 0.0, full-screen close-up, `seconds` long.
    - chapter: at each rejoin beat's start; opens full-screen close-up for
      `closeup_s`, then split-screen for the rest (up to CHAPTER_MAX_S).
    - interlude: short split-screen check-ins dropped into gaps > 110s.
    Total mid-video spots are capped at appearances-1 (intro always kept).
    Never raises.
    """
    try:
        total = max(1.0, float(total or 0))
        seconds = min(15.0, max(2.0, float(seconds or 6)))
        appearances = max(1, int(appearances or 1))
    except (TypeError, ValueError):
        return [{"kind": "intro", "at": 0.0, "dur": 6.0,
                 "closeup_s": 6.0, "seg_idx": 0}]

    plan = [{
        "kind": "intro", "at": 0.0,
        "dur": min(seconds, total * 0.6),
        "closeup_s": min(seconds, total * 0.6),
        "seg_idx": 0,
    }]

    # chapter segments at rejoin beats
    for si in sorted(set(rejoin_seg_idxs or [])):
        try:
            si = int(si)
        except (TypeError, ValueError):
            continue
        if si < 1 or si >= len(seg_durs):
            continue
        start = float(seg_starts[si])
        if start < plan[0]["dur"] - 0.5:
            continue  # never overlap the cold open
        dur = min(CHAPTER_MAX_S, float(seg_durs[si] or 0))
        if dur < MIN_CHAPTER_S:
            continue
        closeup = min(CHAPTER_CLOSEUP_S, dur * 0.4)
        plan.append({"kind": "chapter", "at": round(start, 2),
                     "dur": round(dur, 2), "closeup_s": round(closeup, 2),
                     "seg_idx": si})

    plan.sort(key=lambda p: p["at"])

    # interludes: fill big gaps so the presenter returns every 1-3 min
    if appearances > 1:
        placed = sorted(plan, key=lambda p: p["at"])
        bounds = [(p["at"], p["at"] + p["dur"]) for p in placed]
        bounds.append((total, total))  # tail gap check
        extras = []
        prev_end = bounds[0][1]
        for s, e in bounds[1:]:
            gap = s - prev_end
            if gap > GAP_TRIGGER_S:
                mid = prev_end + gap / 2.0
                at = max(prev_end + 1.0, mid - INTERLUDE_S / 2.0)
                if at + INTERLUDE_S < s - 1.0:
                    extras.append({
                        "kind": "interlude", "at": round(at, 2),
                        "dur": INTERLUDE_S, "closeup_s": 0.0,
                        "seg_idx": _segment_at(mid, seg_starts, seg_durs),
                    })
            prev_end = max(prev_end, e)
        plan.extend(extras)
        plan.sort(key=lambda p: p["at"])

    # cap mid-video spots at appearances-1; intro is always kept.
    # Chapters (real content boundaries) win over gap-fill interludes.
    chapters = [p for p in plan if p["kind"] == "chapter"]
    interludes = [p for p in plan if p["kind"] == "interlude"]
    slots = max(0, appearances - 1)
    mids = chapters[:slots]
    mids += interludes[:max(0, slots - len(mids))]
    plan = [plan[0]] + sorted(mids, key=lambda p: p["at"])
    return plan


def _legacy_plan(total, seconds, appearances):
    """Fallback when no script/segment map is available (old behaviour)."""
    plan = [{
        "kind": "intro", "at": 0.0,
        "dur": min(seconds, total * 0.6),
        "closeup_s": min(seconds, total * 0.6),
        "seg_idx": 0,
    }]
    if appearances > 1 and total > seconds * 2:
        for i in range(1, appearances):
            start = (i / appearances) * total
            plan.append({"kind": "interlude", "at": round(start, 2),
                         "dur": seconds, "closeup_s": 0.0, "seg_idx": 0})
    return plan


def run(job_dir, voiceover_path, presenter, seconds=6, appearances=1,
        total_duration=0.0, logger=None,
        voice_segments=None, script=None, images=None, heygen=None):
    """Build presenter clips. Returns dict. Never raises.

    voice_segments: voiceover stage segments [{name, duration, ...}]
    script: script dict (beats carry rejoin flags)
    images: per-segment B-roll image paths (for split-screen left halves)
    heygen: optional {"pool", "avatar_id", "voice_id", "engine", "enabled"}.
        When enabled and fully configured, the stage renders the whole
        narration as ONE HeyGen talking-head video and cuts the
        intro/mid presenter clips from it (same plan positions). Any
        failure -> silent fall back to the free custom presenter clips.
    """
    job = Path(job_dir)
    avatar_dir = job / "avatar"
    try:
        avatar_dir.mkdir(parents=True, exist_ok=True)
    except Exception:  # noqa: BLE001
        pass

    image = _resolve_image(presenter)
    if not image:
        if logger:
            logger.log("    avatar: no presenter image found — skipping intro")
        return {"intro": "", "mids": [],
                "presenter": (presenter or {}).get("name", "")}

    try:
        seconds = min(15.0, max(2.0, float(seconds or 6)))
    except (TypeError, ValueError):
        seconds = 6.0
    try:
        appearances = int(appearances or 1)
    except (TypeError, ValueError):
        appearances = 1
    appearances = max(1, min(6, appearances))
    total = max(1.0, float(total_duration or 0))

    name = (presenter or {}).get("name", "presenter")
    result = {"intro": "", "mids": [], "presenter": name,
              "provider": "local"}
    images = list(images or [])

    # --- HeyGen talking-head path (paid, opt-in) -------------------------
    heygen_cfg = heygen or {}
    heygen_src, heygen_credits = "", 0.0
    if heygen_cfg.get("enabled"):
        heygen_src, heygen_credits = _heygen_full_video(
            job_dir, script, heygen_cfg, logger)
        if heygen_src:
            result["provider"] = "heygen"
            result["heygen_credits"] = heygen_credits

    # build the voiceover-time map when we have the real data
    plan = None
    try:
        if voice_segments and script:
            starts, durs, cum = [], [], 0.0
            for s in voice_segments:
                starts.append(cum)
                d = float(s.get("duration") or 0)
                durs.append(d)
                cum += d
            beats = script.get("beats") or []
            # voice segments: [hook, beat-0..beat-(n-1), cta]
            rejoin_idxs = [i + 1 for i, b in enumerate(beats)
                           if b.get("rejoin")]
            plan = plan_segments(total or cum, starts, durs, rejoin_idxs,
                                 seconds=seconds, appearances=appearances)
    except Exception:  # noqa: BLE001
        plan = None
    if not plan:
        plan = _legacy_plan(total, seconds, appearances)

    def broll_for(seg_idx):
        try:
            if 0 <= seg_idx < len(images) and Path(images[seg_idx]).is_file():
                return images[seg_idx]
        except Exception:  # noqa: BLE001
            pass
        return ""

    for n, spot in enumerate(plan):
        kind, at, dur = spot["kind"], spot["at"], spot["dur"]
        closeup_s = spot.get("closeup_s") or 0.0
        tag = "intro" if kind == "intro" else f"{kind}-{n}"
        out = avatar_dir / f"{tag}.mp4"
        ok = False
        if heygen_src:
            # HeyGen path: cut the presenter clip from the talking-head
            # video (its own lip-synced audio comes along). The words
            # still match the plan positions — same script, same order.
            ok = _cut_video_clip(heygen_src, at, dur, out, logger)
            if ok and logger and kind == "intro":
                logger.log(f"    avatar intro: {name} (HeyGen talking-head, "
                           f"{dur:.0f}s)")
        if not heygen_src:
            audio = _cut_audio(voiceover_path, at, dur,
                               avatar_dir / f"{tag}-audio")
            if not audio:
                if logger:
                    logger.log(f"    avatar: could not cut audio for {tag} — "
                               "skipping")
                continue
            if kind == "intro" or (kind == "chapter"
                                   and closeup_s >= dur - 0.5):
                # full-screen close-up only
                ok = _closeup_clip(image, audio, out, dur, logger)
            elif kind == "chapter":
                # close-up opening, then hard cut to split-screen
                split_s = max(2.0, dur - closeup_s)
                a1 = _cut_audio(voiceover_path, at, closeup_s,
                                avatar_dir / f"{tag}-a1")
                a2 = _cut_audio(voiceover_path, at + closeup_s, split_s,
                                avatar_dir / f"{tag}-a2")
                p1 = avatar_dir / f"{tag}-p1.mp4"
                p2 = avatar_dir / f"{tag}-p2.mp4"
                broll = broll_for(spot.get("seg_idx", 0)) or image
                if (a1 and a2
                        and _closeup_clip(image, a1, p1, closeup_s,
                                          logger)
                        and _split_clip(image, broll, a2, p2, split_s,
                                        logger)):
                    ok = _concat_parts([p1, p2], out, logger)
            else:  # interlude — short split-screen check-in
                broll = broll_for(spot.get("seg_idx", 0)) or image
                ok = _split_clip(image, broll, audio, out, dur, logger)

        if not ok:
            if logger:
                logger.log(f"    avatar: {tag} render failed — "
                           "continuing without it")
            continue
        entry = {"file": str(out), "at": round(at, 2), "kind": kind}
        if kind == "intro":
            result["intro"] = str(out)
            if logger:
                logger.log(f"    avatar intro: {name} ({dur:.0f}s, "
                           "close-up cold open)")
        else:
            result["mids"].append(entry)
            if logger:
                if kind == "chapter":
                    logger.log(f"    avatar chapter at {at:.0f}s "
                               f"({dur:.0f}s: close-up → split-screen)")
                else:
                    logger.log(f"    avatar interlude at {at:.0f}s "
                               f"({dur:.0f}s split-screen)")

    result["mids"].sort(key=lambda m: m.get("at", 0))
    return result
