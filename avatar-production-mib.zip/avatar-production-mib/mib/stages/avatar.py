"""mib/stages/avatar.py — presenter intro clip (static PNG + slow Ken Burns zoom).

intro.mp4: presenter image with a slow zoompan + the first `seconds` of the
voiceover. Appearances > 1: mid-N.mp4 rejoins cut from evenly spaced points
of the voiceover. Never raises.
"""
from pathlib import Path

from .. import ffmpeg
from ..config import ROOT


def _resolve_image(presenter):
    """Presenter image path -> existing PNG, else a generated placeholder."""
    try:
        rel = (presenter or {}).get("image") or ""
        p = ROOT / rel
        if rel and p.is_file():
            return str(p)
    except Exception:  # noqa: BLE001
        pass
    # fallback: first placeholder that exists, else any png in avatars/
    try:
        av = ROOT / "assets" / "avatars"
        for cand in ("maria.png", "walter.png", "priya.png"):
            if (av / cand).is_file():
                return str(av / cand)
        pngs = sorted(av.glob("*.png"))
        if pngs:
            return str(pngs[0])
    except Exception:  # noqa: BLE001
        pass
    return ""


def _zoom_clip(image_path, audio_path, out_path, duration, logger=None):
    """One zoompan clip. Returns True on success. Never raises."""
    try:
        duration = max(2.0, float(duration))
        rc, _so, se = ffmpeg.run([
            "-y",
            "-framerate", "30", "-loop", "1", "-t", f"{duration:.2f}",
            "-i", image_path,
            "-i", audio_path,
            "-filter_complex",
            "[0:v]scale=1920:1080:force_original_aspect_ratio=increase,crop=1920:1080,"
            "zoompan=z='min(1+0.0009*on,1.12)':"
            "x='iw/2-(iw/zoom/2)':y='ih/2-(ih/zoom/2)':"
            "d=1:s=1920x1080:fps=30[v]",
            "-map", "[v]", "-map", "1:a",
            "-c:v", "libx264", "-pix_fmt", "yuv420p", "-preset", "veryfast",
            "-c:a", "aac", "-ar", "44100", "-ac", "2",
            "-t", f"{duration:.2f}",
            str(out_path),
        ], timeout=600)
        ok = rc == 0 and Path(out_path).is_file()
        if not ok and logger:
            logger.log(f"    avatar clip failed: {(se or '')[-200:]}")
        return ok
    except Exception as e:  # noqa: BLE001
        if logger:
            logger.log(f"    avatar clip error: {e}")
        return False


def _cut_audio(src, start, duration, out_stem):
    """Cut a slice of the voiceover. Returns the output path or ''."""
    try:
        enc, out_path = ffmpeg.audio_track_args(str(out_stem))
        rc, _so, _se = ffmpeg.run([
            "-y", "-ss", f"{max(0.0, start):.2f}", "-t", f"{duration:.2f}",
            "-i", src, "-c:a", enc, "-ar", "44100", "-ac", "2",
            out_path,
        ], timeout=300)
        if rc == 0 and Path(out_path).is_file():
            return out_path
        return ""
    except Exception:  # noqa: BLE001
        return ""


def run(job_dir, voiceover_path, presenter, seconds=6, appearances=1,
        total_duration=0.0, logger=None):
    """Build intro.mp4 (+ mid rejoins). Returns dict. Never raises."""
    job = Path(job_dir)
    avatar_dir = job / "avatar"
    try:
        avatar_dir.mkdir(parents=True, exist_ok=True)
    except Exception:  # noqa: BLE001
        pass

    image = _resolve_image(presenter)
    if not image:
        if logger:
            logger.log("    avatar: no presenter image found — skipping intro")
        return {"intro": "", "mids": [], "presenter": (presenter or {}).get("name", "")}

    try:
        seconds = min(15.0, max(2.0, float(seconds or 6)))
    except (TypeError, ValueError):
        seconds = 6.0
    try:
        appearances = int(appearances or 1)
    except (TypeError, ValueError):
        appearances = 1
    appearances = max(1, min(6, appearances))

    name = (presenter or {}).get("name", "presenter")
    intro_mp4 = avatar_dir / "intro.mp4"
    result = {"intro": "", "mids": [], "presenter": name}

    # intro: first `seconds` of the voiceover
    intro_audio = _cut_audio(voiceover_path, 0, seconds,
                             avatar_dir / "intro-audio")
    if intro_audio:
        if _zoom_clip(image, intro_audio, intro_mp4, seconds, logger):
            result["intro"] = str(intro_mp4)
            if logger:
                logger.log(f"    avatar intro: {name} ({seconds:.0f}s)")
        elif logger:
            logger.log("    avatar: intro render failed — continuing without it")
    elif logger:
        logger.log("    avatar: could not cut intro audio — continuing without it")

    # mid rejoins at evenly spaced points
    if appearances > 1 and total_duration > seconds * 2:
        for i in range(1, appearances):
            frac = i / appearances
            start = frac * total_duration
            mid_audio = _cut_audio(voiceover_path, start, seconds,
                                   avatar_dir / f"mid-{i}-audio")
            mid_mp4 = avatar_dir / f"mid-{i}.mp4"
            if mid_audio:
                if _zoom_clip(image, mid_audio, mid_mp4, seconds, logger):
                    result["mids"].append(
                        {"file": str(mid_mp4), "at": round(start, 2)})
                    if logger:
                        logger.log(f"    avatar rejoin {i}: at {start:.0f}s")

    return result
