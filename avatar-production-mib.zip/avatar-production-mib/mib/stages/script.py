"""mib/stages/script.py — local rules-engine scriptwriter (free, offline).

title + target_minutes -> {hook, beats[{name, narration, image_prompt}],
cta, words, est_minutes}.

Rules:
- hook: curiosity + emotion, <= ~18s (~40 words)
- 6 beats: problem -> complication -> setback -> twist -> payoff -> landing
- CTA: subscribe + comment keyword
- narration ~140 wpm; TTS text sanitized (no headers/stage directions)
- image prompts: photorealistic, 16:9, no text, no watermarks
"""
import hashlib
import re

WPM = 140

HOOKS = [
    "What if everything you believed about {topic} was only half the story? "
    "Stay with me for the next few minutes, because what you are about to "
    "hear changed everything for one family.",
    "Nobody expected what happened next. Not the neighbors, not the experts, "
    "and certainly not the people living through it. This is the story of "
    "{topic}, and it starts with a single quiet moment.",
    "They say some moments choose you. This one began like any ordinary day, "
    "until {topic} turned it into something nobody will ever forget.",
    "If you have ever wondered whether {topic} could really change a life, "
    "this story will answer that question — and the answer surprised everyone.",
]

BEAT_DEFS = [
    ("problem",
     ["Life had settled into a quiet rhythm, and then {topic} arrived without warning.",
      "Nobody knew what to do first. The days felt heavier, and every small decision carried weight.",
      "Neighbors whispered, experts disagreed, and the family at the center of it all just tried to hold on.",
      "What looked simple from the outside was anything but. Every morning brought a new question with no easy answer."],
     "a quiet home interior at dawn, warm lamp light, empty chair by the window, cinematic photorealistic"),
    ("complication",
     ["Just when things seemed stable, a second problem surfaced, and it was bigger than the first.",
      "Doors that used to open easily began to close. Help was promised, then delayed, then questioned.",
      "The family learned a hard truth: waiting changes nothing. Only action moves the story forward.",
      "So they made a choice that nobody around them understood — and that choice set everything in motion."],
     "a person standing at a crossroads at dusk, dramatic sky, cinematic photorealistic"),
    ("setback",
     ["Then came the setback that nearly ended everything. One phone call, one letter, one moment of bad timing.",
      "Hope, which had been growing quietly, suddenly felt fragile. The nights grew longer and the doubts louder.",
      "Even the people who believed the most began to wonder if they had been wrong all along.",
      "But sometimes the darkest hour is simply the hour before the turn."],
     "rain on a window at night, blurred warm lights outside, melancholic cinematic photorealistic"),
    ("twist",
     ["And then, the twist nobody saw coming. A stranger, a letter, a coincidence too perfect to be coincidence.",
      "In a single afternoon, the whole picture changed. What seemed impossible in the morning felt inevitable by evening.",
      "The family would later say this was the moment they stopped surviving and started believing again.",
      "Because {topic} was never really about the problem. It was about what the problem revealed."],
     "sunlight breaking through storm clouds over a small town, hopeful cinematic photorealistic"),
    ("payoff",
     ["What happened next is the part people tell and retell. Step by step, the pieces fell into place.",
      "There were tears, there was laughter, and there was a quiet that felt like peace arriving at last.",
      "The neighbors who had whispered now stood in the yard, watching, smiling, some of them crying too.",
      "This is why the story matters: it proves that patience and heart still win."],
     "an emotional reunion in warm golden light, tears of joy, cinematic photorealistic"),
    ("landing",
     ["Looking back now, every hard day makes sense. Every delay had a reason. Every tear watered something good.",
      "The family keeps one photograph from that season on the mantel — not of the struggle, but of the morning after.",
      "Because the real lesson of {topic} is simple: hold on a little longer than feels reasonable.",
      "And if this story found you at the right moment, maybe that is no accident either."],
     "a framed photograph on a wooden mantel, morning light, peaceful cinematic photorealistic"),
]

CTAS = [
    "If this story moved you, subscribe and turn on notifications, so you never miss the next one. "
    "And tell me in the comments: what moment in your own life felt like this? I read every single one.",
    "Subscribe for more stories like this one, made for hearts that still believe. "
    "Comment below with the word HOPE if this story found you at the right time.",
]

IMG_SUFFIX = ("Photorealistic, cinematic 16:9 composition, warm natural light, "
              "rich detail, no text, no watermark, no logo.")


def sanitize(text):
    """Strip anything that should never be spoken: headers, stage directions,
    markdown, bracketed cues. Never raises."""
    try:
        t = str(text or "")
        t = re.sub(r"\[.*?\]", " ", t)          # [pause], [beat], ...
        t = re.sub(r"\(.*?\)", " ", t)          # (softly), ...
        t = re.sub(r"^#{1,6}\s+", "", t, flags=re.M)  # markdown headers
        t = re.sub(r"[*_~`>]", "", t)           # markdown chars
        t = re.sub(r"\s+", " ", t).strip()
        return t
    except Exception:  # noqa: BLE001
        return str(text or "")[:2000]


def _topic(title):
    t = sanitize(title)
    t = re.sub(r"^\d+\s*[-–:.]?\s*", "", t)
    return t or "this story"


def _pick(items, title, salt):
    h = int(hashlib.md5(f"{salt}:{title}".encode()).hexdigest(), 16)
    return items[h % len(items)]


def _fill(sentences, target_words, topic):
    """Cycle sentences (with the topic filled in) until ~target_words."""
    out, i = [], 0
    words = 0
    while words < target_words and i < 40:
        s = sentences[i % len(sentences)].format(topic=topic)
        out.append(s)
        words += len(s.split())
        i += 1
    return " ".join(out)


def build_script(title, target_minutes=5, channel=None):
    """Build the full script dict. Never raises."""
    try:
        target_minutes = max(1, int(target_minutes or 5))
    except (TypeError, ValueError):
        target_minutes = 5
    topic = _topic(title)
    total_words = target_minutes * 145  # slight margin over 140 wpm
    hook_words = min(45, int(total_words * 0.12))
    cta_words = min(40, int(total_words * 0.08))
    beat_words = max(20, (total_words - hook_words - cta_words) // 6)

    hook = sanitize(_pick(HOOKS, title, "hook").format(topic=topic))
    # trim hook to word budget
    hw = hook.split()
    if len(hw) > hook_words + 10:
        hook = " ".join(hw[:hook_words + 10])

    beats = []
    for idx, (name, sentences, scene) in enumerate(BEAT_DEFS):
        narration = sanitize(_fill(sentences, beat_words, topic))
        beats.append({
            "name": name,
            "narration": narration,
            "image_prompt": f"{scene} illustrating: {topic}. {IMG_SUFFIX}",
        })

    cta = sanitize(_fill([_pick(CTAS, title, "cta")], cta_words, topic))

    words = len(hook.split()) + sum(len(b["narration"].split()) for b in beats) \
        + len(cta.split())
    return {
        "title": sanitize(title),
        "topic": topic,
        "hook": hook,
        "beats": beats,
        "cta": cta,
        "words": words,
        "est_minutes": round(words / WPM, 2),
    }


def save_script(job_dir, script):
    """Write script.json. Never raises (returns path or '')."""
    try:
        from pathlib import Path
        import json
        p = Path(job_dir) / "script.json"
        p.write_text(json.dumps(script, indent=2, ensure_ascii=False),
                     encoding="utf-8")
        return str(p)
    except Exception:  # noqa: BLE001
        return ""
