"""mib/stages/assemble.py — final.mp4: intro + per-beat image segments.

The avatar's spoken slices (intro + rejoins) are CUT OUT of the beat
audio, so the story continues through every appearance — the same words
are never heard twice. Each avatar appearance speaks NEW, continuing
script, like the reference pattern (avatar returns several times, always
with fresh lines). Never raises.
"""
from pathlib import Path

from .. import ffmpeg


def _beat_segment(image, audio, out_path, duration, logger=None):
    try:
        duration = max(1.0, float(duration))
        rc, _so, se = ffmpeg.run([
            "-y",
            "-framerate", "30", "-loop", "1", "-t", f"{duration:.2f}",
            "-i", image,
            "-i", audio,
            "-filter_complex",
            "[0:v]scale=1920:1080:force_original_aspect_ratio=increase,crop=1920:1080,"
            "zoompan=z='min(1+0.0007*on,1.10)':"
            "x='iw/2-(iw/zoom/2)':y='ih/2-(ih/zoom/2)':"
            "d=1:s=1920x1080:fps=30[v]",
            "-map", "[v]", "-map", "1:a",
            "-c:v", "libx264", "-pix_fmt", "yuv420p", "-preset", "veryfast",
            "-c:a", "aac", "-ar", "44100", "-ac", "2",
            "-t", f"{duration:.2f}",
            str(out_path),
        ], timeout=900)
        ok = rc == 0 and Path(out_path).is_file()
        if not ok and logger:
            logger.log(f"    assemble: beat segment failed: {(se or '')[-200:]}")
        return ok
    except Exception as e:  # noqa: BLE001
        if logger:
            logger.log(f"    assemble: beat segment error: {e}")
        return False


def _srt_time(s):
    s = max(0.0, float(s))
    h, rem = divmod(int(s), 3600)
    m, sec = divmod(rem, 60)
    ms = int(round((s - int(s)) * 1000))
    return f"{h:02d}:{m:02d}:{sec:02d},{ms:03d}"


def _burn_subtitles(job_dir, final_mp4, timeline, logger=None):
    """Burn segment subtitles into a copy of final_mp4 (best effort).

    timeline: [(start_s, duration_s, text)]. Mid rejoins get no entries.
    Returns the subtitled path, or final_mp4 unchanged on any failure.
    """
    try:
        job = Path(job_dir)
        srt = job / "subs.srt"
        lines = []
        idx = 1
        for start, dur, text in timeline:
            text = (text or "").strip()
            if not text or dur <= 0:
                continue
            # chunk into readable lines
            words, cur, chunks = text.split(), "", []
            for w_ in words:
                if len(cur) + len(w_) > 42 and cur:
                    chunks.append(cur)
                    cur = w_
                else:
                    cur = (cur + " " + w_).strip()
            if cur:
                chunks.append(cur)
            # ~3s per chunk
            per = max(1.5, dur / max(1, len(chunks)))
            t = start
            for ch_ in chunks:
                lines.append(f"{idx}\n{_srt_time(t)} --> "
                             f"{_srt_time(t + per)}\n{ch_}\n")
                idx += 1
                t += per
        if not lines:
            return str(final_mp4)
        srt.write_text("\n".join(lines), encoding="utf-8")
        subbed = job / "final_subtitled.mp4"
        filt = ("subtitles=" + srt.as_posix().replace(":", "\\:")
                .replace("'", "\\'") +
                ":force_style='FontSize=24,PrimaryColour=&HFFFFFF&,"
                "OutlineColour=&H80000000&,BorderStyle=1,Outline=2,"
                "MarginV=48'")
        rc, _so, se = ffmpeg.run([
            "-y", "-i", str(final_mp4), "-vf", filt,
            "-c:v", "libx264", "-pix_fmt", "yuv420p", "-preset", "veryfast",
            "-c:a", "copy", str(subbed),
        ], timeout=1200)
        if rc == 0 and subbed.is_file():
            if logger:
                logger.log("    subtitles burned in (per-channel toggle ON)")
            return str(subbed)
        if logger:
            logger.log(f"    subtitles skipped (filter unavailable): "
                       f"{(se or '')[-120:]}")
    except Exception as e:  # noqa: BLE001
        if logger:
            logger.log(f"    subtitles skipped: {e}")
    return str(final_mp4)


def _cut_piece(src, start, duration, out_stem, logger=None):
    """Cut [start, start+duration) from an audio file. Returns path or ''."""
    try:
        enc, out_path = ffmpeg.audio_track_args(str(out_stem))
        rc, _so, _se = ffmpeg.run([
            "-y", "-ss", f"{max(0.0, start):.2f}", "-t", f"{duration:.2f}",
            "-i", src, "-c:a", enc, "-ar", "44100", "-ac", "2", out_path,
        ], timeout=300)
        if rc == 0 and Path(out_path).is_file():
            return out_path
        return ""
    except Exception:  # noqa: BLE001
        return ""


def _subtract(iv_start, iv_end, cuts):
    """Remove sorted (s, e) cut intervals from [iv_start, iv_end).

    Returns the remaining [(a, b)] pieces. Never raises.
    """
    pieces, cur = [], iv_start
    for s, e in sorted(cuts):
        if e <= cur or s >= iv_end:
            continue
        if s > cur:
            pieces.append((cur, min(s, iv_end)))
        cur = max(cur, e)
        if cur >= iv_end:
            break
    if cur < iv_end:
        pieces.append((cur, iv_end))
    return [(a, b) for a, b in pieces if b - a > 0.05]


def run(job_dir, segments, images, avatar_result, logger=None,
        subtitles=False, script=None):
    """Assemble final.mp4. Returns (path, duration). Never raises."""
    job = Path(job_dir)
    seg_dir = job / "segments"
    try:
        seg_dir.mkdir(parents=True, exist_ok=True)
    except Exception:  # noqa: BLE001
        pass

    avatar_result = avatar_result or {}
    intro = avatar_result.get("intro") or ""
    mids = sorted(avatar_result.get("mids") or [],
                  key=lambda m: m.get("at", 0))

    # voiceover-time start of each beat
    vstarts, cum = [], 0.0
    for seg in segments:
        vstarts.append(cum)
        cum += seg.get("duration") or 0.0

    # avatar-spoken intervals in voiceover time: (start, end, clip_path)
    spoken = []
    if intro and Path(intro).is_file():
        d = ffmpeg.probe(intro)["duration"] or 0.0
        if d > 0.05:
            spoken.append((0.0, d, intro))
    for m in mids:
        p = m.get("file") or ""
        if p and Path(p).is_file():
            d = ffmpeg.probe(p)["duration"] or 0.0
            at = float(m.get("at") or 0.0)
            if d > 0.05:
                spoken.append((at, at + d, p))
    spoken.sort(key=lambda t: t[0])
    cuts = [(s, e) for s, e, _p in spoken]

    # merge: beat pieces (spoken slices removed) + avatar clips, in time order
    events = []  # (time, is_beat, payload)
    n = min(len(segments), len(images))
    for i in range(n):
        vs = vstarts[i]
        dur = segments[i].get("duration") or 0.0
        if dur <= 0:
            continue
        for a, b in _subtract(vs, vs + dur, cuts):
            events.append((a, True, (i, a - vs, b - a)))
    for s, _e, p in spoken:
        events.append((s, False, p))
    events.sort(key=lambda e: (e[0], 0 if e[1] else 1))

    hook_text = (script or {}).get("hook", "") if script else ""
    final_order, final_texts = [], []
    texted, piece_no = set(), 0
    for _t, is_beat, pay in events:
        if not is_beat:
            final_order.append(pay)
            final_texts.append(hook_text if pay == intro else None)
            continue
        i, off, dur = pay
        seg = segments[i]
        piece_audio = _cut_piece(seg["file"], off, dur,
                                 seg_dir / f"beat-{i:02d}-p{piece_no}")
        piece_no += 1
        if not piece_audio:
            if logger:
                logger.log(f"    assemble: skipping beat piece {i} "
                           f"(audio cut failed)")
            continue
        out = seg_dir / f"beat-{i:02d}-p{piece_no:02d}.mp4"
        if _beat_segment(images[i], piece_audio, out, dur, logger):
            final_order.append(str(out))
            if i in texted:
                final_texts.append(None)
            else:
                texted.add(i)
                final_texts.append(seg.get("text", ""))
        elif logger:
            logger.log(f"    assemble: skipping beat piece {i} "
                       f"(segment failed)")

    if not final_order:
        if logger:
            logger.log("    assemble: no segments — cannot build video")
        return "", 0.0

    # concat demuxer, stream copy
    lst = seg_dir / "concat.txt"
    try:
        with open(lst, "w", encoding="utf-8") as f:
            for p in final_order:
                f.write(f"file '{Path(p).as_posix()}'\n")
    except Exception:  # noqa: BLE001
        return "", 0.0

    final = job / "final.mp4"
    rc, _so, se = ffmpeg.run([
        "-y", "-f", "concat", "-safe", "0", "-i", str(lst),
        "-c", "copy", str(final),
    ], timeout=900)
    if rc != 0 or not final.is_file():
        if logger:
            logger.log(f"    assemble: concat failed: {(se or '')[-200:]}")
        # fallback: re-encode concat (handles any param drift)
        rc, _so, se = ffmpeg.run([
            "-y", "-f", "concat", "-safe", "0", "-i", str(lst),
            "-c:v", "libx264", "-pix_fmt", "yuv420p", "-preset", "veryfast",
            "-c:a", "aac", "-ar", "44100", str(final),
        ], timeout=1200)
        if rc != 0 or not final.is_file():
            if logger:
                logger.log("    assemble: FAILED to produce final.mp4")
            return "", 0.0

    dur = ffmpeg.probe(final)["duration"]
    if logger:
        logger.log(f"    assemble: final.mp4 ({dur:.0f}s)")

    # optional subtitle burn-in (per-channel toggle, default OFF)
    if subtitles:
        timeline = []
        t = 0.0
        for path, text in zip(final_order, final_texts):
            d = ffmpeg.probe(path)["duration"] or 0.0
            timeline.append((t, d, text))
            t += d
        final = Path(_burn_subtitles(job, final, timeline, logger))
        dur = ffmpeg.probe(final)["duration"] or dur

    return str(final), round(dur, 2)
