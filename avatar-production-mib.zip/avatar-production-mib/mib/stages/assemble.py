"""mib/stages/assemble.py — final.mp4: intro + per-beat image segments.

Each beat segment: scene image with slow zoompan, duration = beat audio
duration. All segments share identical codec params so the concat demuxer
can join them with -c copy. Never raises.
"""
from pathlib import Path

from .. import ffmpeg


def _beat_segment(image, audio, out_path, duration, logger=None):
    try:
        duration = max(1.0, float(duration))
        rc, _so, se = ffmpeg.run([
            "-y",
            "-framerate", "30", "-loop", "1", "-t", f"{duration:.2f}",
            "-i", image,
            "-i", audio,
            "-filter_complex",
            "[0:v]scale=1920:1080:force_original_aspect_ratio=increase,crop=1920:1080,"
            "zoompan=z='min(1+0.0007*on,1.10)':"
            "x='iw/2-(iw/zoom/2)':y='ih/2-(ih/zoom/2)':"
            "d=1:s=1920x1080:fps=30[v]",
            "-map", "[v]", "-map", "1:a",
            "-c:v", "libx264", "-pix_fmt", "yuv420p", "-preset", "veryfast",
            "-c:a", "aac", "-ar", "44100", "-ac", "2",
            "-t", f"{duration:.2f}",
            str(out_path),
        ], timeout=900)
        ok = rc == 0 and Path(out_path).is_file()
        if not ok and logger:
            logger.log(f"    assemble: beat segment failed: {(se or '')[-200:]}")
        return ok
    except Exception as e:  # noqa: BLE001
        if logger:
            logger.log(f"    assemble: beat segment error: {e}")
        return False


def _srt_time(s):
    s = max(0.0, float(s))
    h, rem = divmod(int(s), 3600)
    m, sec = divmod(rem, 60)
    ms = int(round((s - int(s)) * 1000))
    return f"{h:02d}:{m:02d}:{sec:02d},{ms:03d}"


def _burn_subtitles(job_dir, final_mp4, timeline, logger=None):
    """Burn segment subtitles into a copy of final_mp4 (best effort).

    timeline: [(start_s, duration_s, text)]. Mid rejoins get no entries.
    Returns the subtitled path, or final_mp4 unchanged on any failure.
    """
    try:
        job = Path(job_dir)
        srt = job / "subs.srt"
        lines = []
        idx = 1
        for start, dur, text in timeline:
            text = (text or "").strip()
            if not text or dur <= 0:
                continue
            # chunk into readable lines
            words, cur, chunks = text.split(), "", []
            for w_ in words:
                if len(cur) + len(w_) > 42 and cur:
                    chunks.append(cur)
                    cur = w_
                else:
                    cur = (cur + " " + w_).strip()
            if cur:
                chunks.append(cur)
            # ~3s per chunk
            per = max(1.5, dur / max(1, len(chunks)))
            t = start
            for ch_ in chunks:
                lines.append(f"{idx}\n{_srt_time(t)} --> "
                             f"{_srt_time(t + per)}\n{ch_}\n")
                idx += 1
                t += per
        if not lines:
            return str(final_mp4)
        srt.write_text("\n".join(lines), encoding="utf-8")
        subbed = job / "final_subtitled.mp4"
        filt = ("subtitles=" + srt.as_posix().replace(":", "\\:")
                .replace("'", "\\'") +
                ":force_style='FontSize=24,PrimaryColour=&HFFFFFF&,"
                "OutlineColour=&H80000000&,BorderStyle=1,Outline=2,"
                "MarginV=48'")
        rc, _so, se = ffmpeg.run([
            "-y", "-i", str(final_mp4), "-vf", filt,
            "-c:v", "libx264", "-pix_fmt", "yuv420p", "-preset", "veryfast",
            "-c:a", "copy", str(subbed),
        ], timeout=1200)
        if rc == 0 and subbed.is_file():
            if logger:
                logger.log("    subtitles burned in (per-channel toggle ON)")
            return str(subbed)
        if logger:
            logger.log(f"    subtitles skipped (filter unavailable): "
                       f"{(se or '')[-120:]}")
    except Exception as e:  # noqa: BLE001
        if logger:
            logger.log(f"    subtitles skipped: {e}")
    return str(final_mp4)


def run(job_dir, segments, images, avatar_result, logger=None,
        subtitles=False, script=None):
    """Assemble final.mp4. Returns (path, duration). Never raises."""
    job = Path(job_dir)
    seg_dir = job / "segments"
    try:
        seg_dir.mkdir(parents=True, exist_ok=True)
    except Exception:  # noqa: BLE001
        pass

    avatar_result = avatar_result or {}
    ordered = []
    if avatar_result.get("intro"):
        ordered.append(avatar_result["intro"])

    # mid rejoins keyed by their voiceover timestamp
    mids = sorted(avatar_result.get("mids") or [], key=lambda m: m.get("at", 0))

    # build beat segments; cumulative start time per segment
    starts = []
    cum = 0.0
    beat_files = []
    n = min(len(segments), len(images))
    for i in range(n):
        seg = segments[i]
        img = images[i]
        dur = seg.get("duration") or 5.0
        out = seg_dir / f"beat-{i:02d}.mp4"
        if _beat_segment(img, seg["file"], out, dur, logger):
            starts.append(cum)
            beat_files.append(str(out))
            cum += dur
        elif logger:
            logger.log(f"    assemble: skipping beat {i} (segment failed)")

    if not beat_files:
        if logger:
            logger.log("    assemble: no beat segments — cannot build video")
        return "", 0.0

    # interleave mids: insert before the first beat starting at/after mid.at
    # (texts travel alongside: intro -> hook, beats -> narration, mids -> None)
    hook_text = (script or {}).get("hook", "") if script else ""
    final_order = list(ordered)
    final_texts = [hook_text] * len(ordered)
    mid_idx = 0
    for i, bf in enumerate(beat_files):
        while mid_idx < len(mids) and mids[mid_idx].get("at", 0) <= starts[i]:
            final_order.append(mids[mid_idx]["file"])
            final_texts.append(None)  # rejoins: no subtitle entries
            mid_idx += 1
        final_order.append(bf)
        final_texts.append(segments[i].get("text", "") if i < len(segments)
                           else "")
    while mid_idx < len(mids):
        final_order.append(mids[mid_idx]["file"])
        final_texts.append(None)
        mid_idx += 1

    # concat demuxer, stream copy
    lst = seg_dir / "concat.txt"
    try:
        with open(lst, "w", encoding="utf-8") as f:
            for p in final_order:
                f.write(f"file '{Path(p).as_posix()}'\n")
    except Exception:  # noqa: BLE001
        return "", 0.0

    final = job / "final.mp4"
    rc, _so, se = ffmpeg.run([
        "-y", "-f", "concat", "-safe", "0", "-i", str(lst),
        "-c", "copy", str(final),
    ], timeout=900)
    if rc != 0 or not final.is_file():
        if logger:
            logger.log(f"    assemble: concat failed: {(se or '')[-200:]}")
        # fallback: re-encode concat (handles any param drift)
        rc, _so, se = ffmpeg.run([
            "-y", "-f", "concat", "-safe", "0", "-i", str(lst),
            "-c:v", "libx264", "-pix_fmt", "yuv420p", "-preset", "veryfast",
            "-c:a", "aac", "-ar", "44100", str(final),
        ], timeout=1200)
        if rc != 0 or not final.is_file():
            if logger:
                logger.log("    assemble: FAILED to produce final.mp4")
            return "", 0.0

    dur = ffmpeg.probe(final)["duration"]
    if logger:
        logger.log(f"    assemble: final.mp4 ({dur:.0f}s)")

    # optional subtitle burn-in (per-channel toggle, default OFF)
    if subtitles:
        timeline = []
        t = 0.0
        for path, text in zip(final_order, final_texts):
            d = ffmpeg.probe(path)["duration"] or 0.0
            timeline.append((t, d, text))
            t += d
        final = Path(_burn_subtitles(job, final, timeline, logger))
        dur = ffmpeg.probe(final)["duration"] or dur

    return str(final), round(dur, 2)
