"""mib/config.py — config.yaml + secrets.yaml load/save. Never crashes.

Frozen (PyInstaller exe) behaviour: the exe extracts to a throwaway temp dir,
so ALL writable state (config, secrets, avatars, output) lives in
%APPDATA%/AvatarProductionByMIB, seeded once from the bundled defaults.
Unfrozen (dev): everything lives next to the source tree, as before.
"""
import os
import shutil
import sys
from pathlib import Path

import yaml


def _bundle_dir():
    """Read-only bundled files: PyInstaller _MEIPASS, else the source tree."""
    meipass = getattr(sys, "_MEIPASS", None)
    if meipass:
        return Path(meipass)
    return Path(__file__).resolve().parent.parent


def _app_dir():
    """Writable, persistent app dir (frozen) or source tree (dev)."""
    if getattr(sys, "frozen", False):
        base = os.environ.get("APPDATA") or str(Path.home())
        d = Path(base) / "AvatarProductionByMIB"
    else:
        d = Path(__file__).resolve().parent.parent
    try:
        d.mkdir(parents=True, exist_ok=True)
    except Exception:
        pass
    return d


BUNDLE_DIR = _bundle_dir()
ROOT = _app_dir()
CONFIG_PATH = ROOT / "config" / "config.yaml"
SECRETS_PATH = ROOT / "config" / "secrets.yaml"
SECRETS_EXAMPLE = ROOT / "config" / "secrets.yaml.example"

DEFAULT_CONFIG = {
    "channels": {
        "behind-the-hug": {
            "name": "Behind The Hug",
            "niche": "Emotional soldier-dog reunion stories for a 65+ audience.",
            "default_minutes": 30,
            "mode": "avatar",
            "presenter": "maria",
            "voice": {"provider": "edge", "voice_id": "en-US-AvaNeural"},
            "subtitles": False,
        },
        "kustorez-amish": {
            "name": "Kustorez Amish",
            "niche": "Amish gardening & self-reliant home wisdom for seniors.",
            "default_minutes": 15,
            "mode": "avatar",
            "presenter": "walter",
            "voice": {"provider": "edge", "voice_id": "en-US-AndrewNeural"},
            "subtitles": False,
        },
    },
    "presenters": [
        {"id": "maria", "name": "Maria", "image": "assets/avatars/maria.png",
         "gender": "f"},
        {"id": "walter", "name": "Walter", "image": "assets/avatars/walter.png",
         "gender": "m"},
        {"id": "priya", "name": "Priya", "image": "assets/avatars/priya.png",
         "gender": "f"},
    ],
    "providers": {
        "voice_order": ["channel", "edge"],
        "script_provider": "local",
        "ai33pro_llm_base_url": "",
        "ai33pro_llm_model": "",
        "image_order": ["grok", "gemini", "local"],
        "gemini_model": "gemini-2.5-flash-image",
        "grok_model": "grok-imagine-image",
        "presenter_seconds": 6,
        "appearances": 1,
    },
}

DEFAULT_SECRETS = {
    "ai33pro_api_key": "",
    "gemini_api_key": "",
    "xai_api_key": "",
}


def _read_yaml(path):
    try:
        if Path(path).exists():
            data = yaml.safe_load(Path(path).read_text(encoding="utf-8"))
            return data if isinstance(data, dict) else {}
    except Exception:
        pass
    return {}


def _write_yaml(path, data):
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    tmp = p.with_suffix(p.suffix + ".tmp")
    tmp.write_text(yaml.safe_dump(data, sort_keys=False, allow_unicode=True),
                   encoding="utf-8")
    shutil.move(str(tmp), str(p))


def load_config():
    """Load config.yaml merged over defaults. Never raises."""
    cfg = {k: (dict(v) if isinstance(v, dict) else v)
           for k, v in DEFAULT_CONFIG.items()}
    user = _read_yaml(CONFIG_PATH)
    for k, v in user.items():
        cfg[k] = v
    if not CONFIG_PATH.exists():
        try:
            _write_yaml(CONFIG_PATH, cfg)
        except Exception:
            pass
    return cfg


def save_config(cfg):
    """Persist config.yaml. Never raises (returns True/False)."""
    try:
        _write_yaml(CONFIG_PATH, cfg)
        return True
    except Exception:
        return False


def load_secrets():
    """Load secrets.yaml. Missing file -> defaults (all empty). Never raises."""
    sec = dict(DEFAULT_SECRETS)
    sec.update(_read_yaml(SECRETS_PATH))
    return sec


def save_secrets(sec):
    """Persist secrets.yaml. Never raises (returns True/False)."""
    try:
        merged = dict(DEFAULT_SECRETS)
        merged.update(sec or {})
        _write_yaml(SECRETS_PATH, merged)
        return True
    except Exception:
        return False


def ensure_secrets_file():
    """Create secrets.yaml from the example when missing. Never raises."""
    try:
        if not SECRETS_PATH.exists():
            for cand in (SECRETS_EXAMPLE, BUNDLE_DIR / "config" / "secrets.yaml.example"):
                if cand.exists():
                    shutil.copy(str(cand), str(SECRETS_PATH))
                    return
            _write_yaml(SECRETS_PATH, dict(DEFAULT_SECRETS))
    except Exception:
        pass


def seed_app_dir():
    """Frozen exe first-run: copy bundled defaults into the writable app dir.

    Seeds config.yaml (when absent), secrets.yaml.example, and the placeholder
    avatar PNGs. Dev mode: no-op. Never raises.
    """
    try:
        if not getattr(sys, "frozen", False):
            return
        bconf = BUNDLE_DIR / "config"
        if not CONFIG_PATH.exists() and (bconf / "config.yaml").exists():
            (ROOT / "config").mkdir(parents=True, exist_ok=True)
            shutil.copy(str(bconf / "config.yaml"), str(CONFIG_PATH))
        if not SECRETS_EXAMPLE.exists() and (bconf / "secrets.yaml.example").exists():
            (ROOT / "config").mkdir(parents=True, exist_ok=True)
            shutil.copy(str(bconf / "secrets.yaml.example"), str(SECRETS_EXAMPLE))
        bav = BUNDLE_DIR / "assets" / "avatars"
        tav = ROOT / "assets" / "avatars"
        if bav.is_dir():
            tav.mkdir(parents=True, exist_ok=True)
            for png in bav.glob("*.png"):
                dest = tav / png.name
                if not dest.exists():
                    shutil.copy(str(png), str(dest))
    except Exception:
        pass
