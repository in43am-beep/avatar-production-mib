"""mib/ui/autopilot_dialog.py — fully automatic URL -> video.

Paste a reference YouTube video URL and press "Start auto-pilot":
study -> 20 viral titles -> top-ranked title -> Amish storyteller
script -> locked-character thumbnail prompt -> video. Zero manual
steps in between (with script-LLM keys configured).

No script-LLM key -> the chain stops after the study with the
copy-paste title prompt (clear message, free/local fallback).
"""
from PySide6.QtCore import QThread, Signal
from PySide6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QLineEdit,
    QTextEdit, QProgressBar,
)

from .. import autopilot as _ap
from ..pipeline import run_pipeline
from ..prompts import viral_titles as _vt
from .titles_dialog import _TitlesWorker, PromptCopyDialog


class _AutoWorker(QThread):
    """Run the whole chain in the background.

    Signals: progress(int, str), log(str), finished(dict).
    """
    progress = Signal(int, str)
    log = Signal(str)
    finished = Signal(dict)

    def __init__(self, url, channel_id, cfg, secrets):
        super().__init__()
        self.url = url
        self.channel_id = channel_id or ""
        self.cfg = cfg or {}
        self.secrets = secrets or {}

    def _titles_caller(self, prompt):
        """Real titles caller: shares _TitlesWorker's pool logic."""
        helper = _TitlesWorker(self.cfg, self.secrets, self.channel_id)
        raw = helper._call_llm(prompt)
        titles = _vt.parse_titles(raw)
        if not titles:
            raise ValueError("The LLM returned no numbered titles.")
        return titles, raw

    def run(self):  # noqa: D102
        res = _ap.run_chain(
            self.url, self.channel_id, self.cfg, self.secrets,
            titles_caller=self._titles_caller,
            pipeline_fn=run_pipeline,
            progress_cb=lambda p, m: self.progress.emit(int(p), str(m)),
            log_cb=lambda line: self.log.emit(str(line)))
        self.finished.emit(res)


class AutopilotDialog(QDialog):
    """Paste URL -> start -> full video, automatically."""

    def __init__(self, parent, cfg, secrets, channel_id):
        super().__init__(parent)
        self.cfg = cfg or {}
        self.secrets = secrets or {}
        self.channel_id = channel_id or ""
        self.setWindowTitle("Auto-pilot: video from a reference URL")
        self.resize(640, 520)
        self._worker = None

        lay = QVBoxLayout(self)
        lay.addWidget(QLabel("<b>🤖 Auto-pilot</b>"))
        info = QLabel(
            "Paste a reference YouTube video URL. The app studies its "
            "packaging (formulas only, never content), generates 20 viral "
            "titles with the script LLM, takes the top-ranked title, "
            "writes the script in Amish storyteller mode, builds the "
            "locked-character thumbnail prompt, and produces the video — "
            "no manual steps in between. Needs script-LLM keys "
            "(Settings → API Keys); without one it stops with a "
            "copy-paste prompt.")
        info.setWordWrap(True)
        lay.addWidget(info)

        urow = QHBoxLayout()
        self.url_edit = QLineEdit()
        self.url_edit.setPlaceholderText(
            "https://www.youtube.com/watch?v=…")
        self.start_btn = QPushButton("Start auto-pilot")
        self.start_btn.setObjectName("primary")
        self.start_btn.clicked.connect(self._start)
        urow.addWidget(self.url_edit, 1)
        urow.addWidget(self.start_btn)
        lay.addLayout(urow)

        self.bar = QProgressBar()
        self.bar.setRange(0, 100)
        self.bar.setValue(0)
        lay.addWidget(self.bar)

        self.status = QLabel("")
        self.status.setWordWrap(True)
        lay.addWidget(self.status)

        lay.addWidget(QLabel("live log"))
        self.log = QTextEdit()
        self.log.setReadOnly(True)
        lay.addWidget(self.log, 1)

        row = QHBoxLayout()
        row.addStretch(1)
        close = QPushButton("Close")
        close.clicked.connect(self.reject)
        row.addWidget(close)
        lay.addLayout(row)

    # ------------------------------------------------------------- actions
    def _start(self):
        url = self.url_edit.text().strip()
        if not url:
            self.status.setText("Paste a YouTube video URL first.")
            return
        self.start_btn.setEnabled(False)
        self.url_edit.setEnabled(False)
        self.log.clear()
        self._worker = _AutoWorker(url, self.channel_id, self.cfg,
                                   self.secrets)
        self._worker.progress.connect(self._on_progress)
        self._worker.log.connect(self._on_log)
        self._worker.finished.connect(self._on_finished)
        self._worker.start()

    def _on_progress(self, pct, msg):
        self.bar.setValue(max(0, min(100, pct)))
        self.status.setText(msg)

    def _on_log(self, line):
        self.log.append(line)

    def _on_finished(self, res):
        self.start_btn.setEnabled(True)
        self.url_edit.setEnabled(True)
        if res.get("ok"):
            self.bar.setValue(100)
            pres = res.get("pipeline_result") or {}
            self.status.setText(
                f"✓ Done — '{res.get('title', '')[:60]}' · "
                f"{pres.get('duration_s', 0):.0f}s · "
                f"${pres.get('total_cost_usd', 0):.2f}\n"
                f"Output: {pres.get('job_dir', '')}")
        elif res.get("prompt_text"):
            self.status.setText(f"⚠ {res.get('error', '')}")
            PromptCopyDialog(
                self, "Copy the title prompt",
                res.get("prompt_text") or "",
                "The study worked, but titles need a script-LLM key "
                "(or paste this prompt into any chatbot).").exec()
        else:
            self.status.setText(f"⚠ {res.get('error') or 'failed'}")
