"""mib/ui/study_dialog.py — viral-topic "Study" flow dialog.

Paste a competitor YouTube video URL -> the app fetches its metadata at
runtime on the user's PC (public oEmbed + watch page, NO API key) ->
decodes the packaging mechanics (title formula, thumbnail formula,
description CTA order, hook) -> generates 10 ORIGINAL topic candidates
in the same niche, scored against the channel's Pattern profile ->
the user picks topics into the normal batch flow (wizard Title step).

The study is saved as a markdown note:
  output/<channel>/studies/<video-id>.md

Study first, produce second: decode the craft, never copy the content.
"""
from pathlib import Path

from PySide6.QtCore import Qt, QThread, Signal
from PySide6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QLineEdit,
    QTextEdit, QListWidget, QListWidgetItem,
)

from ..config import ROOT


class _StudyFetchWorker(QThread):
    """Fetch video metadata in the background. Signals: done(dict)."""
    done = Signal(dict)

    def __init__(self, url, thumb_dir):
        super().__init__()
        self.url = url
        self.thumb_dir = thumb_dir

    def run(self):  # noqa: D102
        try:
            from .. import study as _s
            meta = _s.fetch_metadata(self.url, thumb_dir=self.thumb_dir)
        except Exception as e:  # noqa: BLE001
            meta = {"error": f"Fetch failed: {e}"[:300]}
        self.done.emit(meta)


def _mechanics_text(meta, mech):
    """Readable mechanics summary for the dialog box. Never raises."""
    try:
        tf = (mech or {}).get("title_formula") or {}
        td = (mech or {}).get("description") or {}
        th = (mech or {}).get("thumbnail") or {}
        views = int((meta or {}).get("views") or 0)
        lines = [
            f"Title: {(meta or {}).get('title', '')}",
            f"Author: {(meta or {}).get('author', '')} · "
            f"Views: {views:,} · Published: {(meta or {}).get('published') or 'n/a'}",
            "",
            "TITLE FORMULA (decoded):",
            f"  length {tf.get('length', 0)} chars · case {tf.get('case', '')}",
            f"  numbers: {', '.join(tf.get('numbers') or []) or 'none'}",
            f"  bracket tags: {', '.join(tf.get('bracket_tags') or []) or 'none'}",
            "",
            "THUMBNAIL:",
            f"  brightness: {th.get('brightness') or 'n/a'} · "
            f"colors: {', '.join(th.get('dominant_colors') or []) or 'n/a'}",
            "",
            "DESCRIPTION CTA ORDER:",
            f"  {' → '.join(td.get('cta_order') or []) or 'n/a'}",
            "",
            f"HOOK: {(mech or {}).get('hook') or 'n/a'}",
            f"CHAPTERS: {len((mech or {}).get('chapters') or [])} detected",
        ]
        return "\n".join(lines)
    except Exception:  # noqa: BLE001
        return "Could not summarize mechanics."


class StudyDialog(QDialog):
    """Study a competitor video -> scored topics -> into the batch."""

    def __init__(self, parent, cfg, channel_id):
        super().__init__(parent)
        self.cfg = cfg or {}
        self.channel_id = channel_id or ""
        self.setWindowTitle("Study a competitor video")
        self.resize(620, 560)
        self.chosen_titles = []

        lay = QVBoxLayout(self)
        lay.addWidget(QLabel("<b>🔍 Study</b>"))
        info = QLabel("Paste a competitor's YouTube video URL. The app "
                      "fetches its public metadata on your PC (no API key), "
                      "decodes the packaging formula, and generates 10 "
                      "original topics in the same niche — scored against "
                      "this channel's Pattern. Formulas only, never content.")
        info.setWordWrap(True)
        lay.addWidget(info)

        urow = QHBoxLayout()
        self.url_edit = QLineEdit()
        self.url_edit.setPlaceholderText(
            "https://www.youtube.com/watch?v=…")
        self.fetch_btn = QPushButton("Fetch")
        self.fetch_btn.clicked.connect(self._fetch)
        urow.addWidget(self.url_edit, 1)
        urow.addWidget(self.fetch_btn)
        lay.addLayout(urow)

        self.status = QLabel("")
        lay.addWidget(self.status)

        self.mech_box = QTextEdit()
        self.mech_box.setReadOnly(True)
        self.mech_box.setMaximumHeight(220)
        lay.addWidget(self.mech_box)

        self.gen_btn = QPushButton("Generate 10 topics (scored)")
        self.gen_btn.setEnabled(False)
        self.gen_btn.clicked.connect(self._generate)
        lay.addWidget(self.gen_btn)

        self.topic_list = QListWidget()
        lay.addWidget(self.topic_list, 1)

        row = QHBoxLayout()
        add_btn = QPushButton("Add selected to batch")
        add_btn.setObjectName("primary")
        add_btn.clicked.connect(self._add_selected)
        close_btn = QPushButton("Close")
        close_btn.clicked.connect(self.reject)
        row.addStretch(1)
        row.addWidget(close_btn)
        row.addWidget(add_btn)
        lay.addLayout(row)

        self.meta, self.mech, self.topics = {}, {}, []
        self._worker = None

    # ------------------------------------------------------------- actions
    def _study_dir(self):
        d = ROOT / "output" / (self.channel_id or "default") / "studies"
        try:
            d.mkdir(parents=True, exist_ok=True)
        except Exception:  # noqa: BLE001
            pass
        return d

    def _fetch(self):
        url = self.url_edit.text().strip()
        if not url:
            self.status.setText("Paste a YouTube video URL first.")
            return
        self.fetch_btn.setEnabled(False)
        self.status.setText("Fetching public metadata…")
        self._worker = _StudyFetchWorker(url, str(self._study_dir()))
        self._worker.done.connect(self._on_fetched)
        self._worker.start()

    def _on_fetched(self, meta):
        self.fetch_btn.setEnabled(True)
        self.meta = meta or {}
        err = self.meta.get("error")
        if err:
            self.status.setText(f"⚠ {err}")
            self.mech_box.clear()
            self.gen_btn.setEnabled(False)
            return
        from .. import study as _s
        self.mech = _s.decode_mechanics(self.meta)
        self.mech_box.setPlainText(_mechanics_text(self.meta, self.mech))
        self.status.setText("✓ Metadata fetched — review the formula, "
                            "then generate topics.")
        self.gen_btn.setEnabled(True)

    def _generate(self):
        from .. import study as _s
        from ..patterns import get_pattern
        ch = (self.cfg.get("channels") or {}).get(self.channel_id) or {}
        try:
            pattern = get_pattern(ch, self.channel_id)
        except Exception:  # noqa: BLE001
            pattern = {}
        self.topics = _s.score_topics(self.meta, self.mech, pattern,
                                      ch.get("niche", ""))
        self.topic_list.clear()
        for t in self.topics:
            it = QListWidgetItem(f"[{t['score']}/10] {t['title']}")
            it.setFlags(it.flags() | Qt.ItemIsUserCheckable)
            it.setCheckState(Qt.Checked if t["score"] >= 6 else Qt.Unchecked)
            it.setToolTip(t.get("why", ""))
            it.setData(Qt.UserRole, t["title"])
            self.topic_list.addItem(it)
        self.status.setText(f"{len(self.topics)} topics generated — tick "
                            "the ones you want, then 'Add selected'.")

    def _add_selected(self):
        chosen = [self.topic_list.item(i).data(Qt.UserRole)
                  for i in range(self.topic_list.count())
                  if self.topic_list.item(i).checkState() == Qt.Checked]
        if not chosen:
            self.status.setText("Tick at least one topic first.")
            return
        # save the study note (title + mechanics + topics)
        try:
            from .. import study as _s
            vid = (self.meta or {}).get("video_id") or "study"
            note = str(self._study_dir() / f"{vid}.md")
            _s.save_study_note(note, self.meta, self.mech, self.topics)
            self.status.setText(f"Study note saved → studies/{vid}.md")
        except Exception:  # noqa: BLE001
            pass
        self.chosen_titles = chosen
        self.accept()
