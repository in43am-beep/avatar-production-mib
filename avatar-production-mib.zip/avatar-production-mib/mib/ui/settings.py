"""mib/ui/settings.py — provider options (the user's explicit requirements).

Every provider: enable toggle (key present), status dot, Test button.
Free default always works with zero keys.
"""
from pathlib import Path

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QLineEdit,
    QTabWidget, QWidget, QFormLayout, QComboBox, QListWidget, QListWidgetItem,
    QFileDialog, QMessageBox, QSpinBox, QCheckBox, QDialogButtonBox,
)

from .. import costs
from ..config import save_config, save_secrets
from ..providers import ai33voice, edgevoice
from . import theme

GOLD = theme.GOLD


def status_dot(ok):
    lbl = QLabel("●")
    lbl.setStyleSheet(
        f"color: {'#43c488' if ok else '#5a6272'}; font-size: 18px;")
    return lbl


class VoicePickerDialog(QDialog):
    """Pick a voice -> (provider, voice_id, name)."""

    def __init__(self, parent, cfg, secrets):
        super().__init__(parent)
        self.cfg = cfg
        self.secrets = secrets
        self.result = None
        self.setWindowTitle("Pick a voice")
        self.resize(560, 480)
        lay = QVBoxLayout(self)
        lay.addWidget(QLabel("Free Edge voices (no key needed):"))
        self.edge_list = QListWidget()
        self.edge_list.itemDoubleClicked.connect(self.accept_edge)
        lay.addWidget(self.edge_list)
        for v in edgevoice.list_voices():
            QListWidgetItem(f"{v['name']}  [{v['id']}]", self.edge_list)
        if not self.edge_list.count():
            QListWidgetItem("(offline — type an Edge voice id manually)",
                            self.edge_list)

        row = QHBoxLayout()
        row.addWidget(QLabel("…or type any voice id:"))
        self.manual = QLineEdit()
        self.manual.setPlaceholderText("en-US-AvaNeural or clone_123 …")
        row.addWidget(self.manual)
        lay.addLayout(row)

        key = (secrets.get("ai33pro_api_key") or "").strip()
        if key:
            b = QPushButton("Load AI33 Pro voices…")
            b.clicked.connect(lambda: self.load_ai33(key))
            lay.addWidget(b)
            self.ai33_list = QListWidget()
            self.ai33_list.itemDoubleClicked.connect(self.accept_ai33)
            lay.addWidget(self.ai33_list)

        btns = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        btns.accepted.connect(self.accept_manual)
        btns.rejected.connect(self.reject)
        lay.addWidget(btns)

    def accept_edge(self, item):
        txt = item.text()
        vid = txt.split("[")[-1].rstrip("]") if "[" in txt else txt
        name = txt.split("[")[0].strip()
        self.result = ("edge", vid, name)
        self.accept()

    def accept_manual(self):
        vid = self.manual.text().strip()
        if not vid:
            # fall back to first edge selection
            it = self.edge_list.currentItem()
            if it:
                self.accept_edge(it)
                return
            QMessageBox.warning(self, "Voice", "Pick or type a voice id.")
            return
        prov = "ai33pro" if vid.startswith(
            ("clone_", "elevenlabs_", "minimax_", "kokoro_", "vbee_",
             "fishaudio_", "edge_")) else "edge"
        self.result = (prov, vid, vid)
        self.accept()

    def load_ai33(self, key):
        self.ai33_list.clear()
        try:
            for v in ai33voice.list_voices(key, page_size=50):
                QListWidgetItem(
                    f"{v['name']}  [{v['provider_label']}]  <{v['id']}>",
                    self.ai33_list)
        except ai33voice.AI33Error as e:
            QMessageBox.warning(self, "AI33 Pro", str(e))

    def accept_ai33(self, item):
        txt = item.text()
        vid = txt.split("<")[-1].rstrip(">")
        name = txt.split("[")[0].strip()
        self.result = ("ai33pro", vid, name)
        self.accept()


class SettingsDialog(QDialog):
    def __init__(self, parent, cfg, secrets):
        super().__init__(parent)
        self.cfg = cfg
        self.secrets = dict(secrets)
        self.setWindowTitle("Settings — providers & channels")
        self.resize(720, 600)
        lay = QVBoxLayout(self)
        tabs = QTabWidget()
        tabs.addTab(self._voice_tab(), "Voiceover")
        tabs.addTab(self._script_tab(), "Script")
        tabs.addTab(self._clone_tab(), "Voice Clone")
        tabs.addTab(self._images_tab(), "Images")
        tabs.addTab(self._channels_tab(), "Channels")
        lay.addWidget(tabs)
        row = QHBoxLayout()
        row.addStretch(1)
        save = QPushButton("Save")
        save.setObjectName("primary")
        save.clicked.connect(self.save)
        close = QPushButton("Close")
        close.clicked.connect(self.reject)
        row.addWidget(save)
        row.addWidget(close)
        lay.addLayout(row)

    # ------------------------------------------------ voiceover
    def _voice_tab(self):
        w = QWidget()
        lay = QVBoxLayout(w)
        lay.addWidget(QLabel("AI33 Pro — voiceover & cloning (one key for both)"))
        row = QHBoxLayout()
        self.ai33_key = QLineEdit()
        self.ai33_key.setEchoMode(QLineEdit.Password)
        self.ai33_key.setText(self.secrets.get("ai33pro_api_key", ""))
        self.ai33_key.setPlaceholderText("paste ai33.pro key…")
        self.ai33_dot = status_dot(bool(self.ai33_key.text().strip()))
        test = QPushButton("Test")
        test.clicked.connect(self.test_ai33)
        self.ai33_msg = QLabel("")
        self.ai33_msg.setObjectName("muted")
        row.addWidget(self.ai33_dot)
        row.addWidget(self.ai33_key, 1)
        row.addWidget(test)
        lay.addLayout(row)
        lay.addWidget(self.ai33_msg)
        browse = QPushButton("Browse AI33 voices…")
        browse.clicked.connect(self.browse_ai33)
        lay.addWidget(browse)
        lay.addWidget(QLabel("Free fallback: Edge TTS (no key). "
                             "Speed 85 ≈ rate -15%."))
        lay.addStretch(1)
        info = QLabel("One-time select per channel: Channels tab → pick a "
                      "voice → every video for that channel uses it.")
        info.setObjectName("muted")
        info.setWordWrap(True)
        lay.addWidget(info)
        return w

    def test_ai33(self):
        key = self.ai33_key.text().strip()
        if not key:
            self.ai33_msg.setText("Paste a key first.")
            self.ai33_dot.setStyleSheet("color: #5a6272; font-size: 18px;")
            return
        try:
            bal = ai33voice.get_credits(key)
            self.ai33_msg.setText(f"OK — credit balance: {bal}")
            self.ai33_dot.setStyleSheet("color: #43c488; font-size: 18px;")
        except ai33voice.AI33Error as e:
            self.ai33_msg.setText(str(e))
            self.ai33_dot.setStyleSheet("color: #e5534b; font-size: 18px;")

    def browse_ai33(self):
        key = self.ai33_key.text().strip()
        if not key:
            QMessageBox.warning(self, "AI33 Pro", "Paste the API key first.")
            return
        dlg = VoicePickerDialog(self, self.cfg, {"ai33pro_api_key": key})
        if hasattr(dlg, "ai33_list"):
            dlg.load_ai33(key)
        dlg.exec()  # pick for preview only; locking happens in Channels tab

    # ------------------------------------------------ script
    def _script_tab(self):
        w = QWidget()
        lay = QVBoxLayout(w)
        lay.addWidget(QLabel("Script writer"))
        provs = self.cfg.get("providers") or {}
        self.script_provider = QComboBox()
        self.script_provider.addItems(["local", "ai33pro"])
        cur = provs.get("script_provider", "local")
        self.script_provider.setCurrentText(
            cur if cur in ("local", "ai33pro") else "local")
        lay.addWidget(QLabel("Provider:"))
        lay.addWidget(self.script_provider)
        form = QFormLayout()
        self.llm_base = QLineEdit(provs.get("ai33pro_llm_base_url", ""))
        self.llm_base.setPlaceholderText("https://api.ai33.pro/v1 (OpenAI-compatible)")
        self.llm_model = QLineEdit(provs.get("ai33pro_llm_model", ""))
        self.llm_model.setPlaceholderText("model id, e.g. gpt-4o-mini")
        form.addRow("Base URL:", self.llm_base)
        form.addRow("Model:", self.llm_model)
        lay.addLayout(form)
        self.llm_msg = QLabel("")
        self.llm_msg.setObjectName("muted")
        self.llm_msg.setWordWrap(True)
        test = QPushButton("Test")
        test.clicked.connect(self.test_llm)
        lay.addWidget(test)
        lay.addWidget(self.llm_msg)
        lay.addStretch(1)
        info = QLabel("Uses the SAME ai33pro key as voiceover (Voiceover tab). "
                      "Any LLM failure falls back to the free local rules engine.")
        info.setObjectName("muted")
        info.setWordWrap(True)
        lay.addWidget(info)
        return w

    def test_llm(self):
        from ..providers import scriptllm
        key = self.ai33_key.text().strip()
        try:
            scr = scriptllm.generate("The dog who waited 400 days", 1, key,
                                     self.llm_base.text().strip(),
                                     self.llm_model.text().strip(),
                                     timeout=120)
            self.llm_msg.setText(f"OK — {scr['words']} words returned.")
        except Exception as e:  # noqa: BLE001
            self.llm_msg.setText(str(e)[:300])

    # ------------------------------------------------ clone
    def _clone_tab(self):
        w = QWidget()
        lay = QVBoxLayout(w)
        lay.addWidget(QLabel("Clone a voice, lock it to a channel's avatar"))
        form = QFormLayout()
        self.clone_channel = QComboBox()
        for cid, ch in (self.cfg.get("channels") or {}).items():
            self.clone_channel.addItem(ch.get("name", cid), cid)
        self.clone_name = QLineEdit()
        self.clone_name.setPlaceholderText("e.g. Maria warm")
        srow = QHBoxLayout()
        self.clone_sample = QLineEdit()
        self.clone_sample.setPlaceholderText("1–3 min mp3/wav, clear speech, no music…")
        self.clone_sample.setReadOnly(True)
        pick = QPushButton("Choose file…")
        pick.clicked.connect(self.pick_sample)
        srow.addWidget(self.clone_sample, 1)
        srow.addWidget(pick)
        form.addRow("Channel:", self.clone_channel)
        form.addRow("Clone name:", self.clone_name)
        form.addRow("Sample:", srow)
        lay.addLayout(form)
        create = QPushButton("Create clone")
        create.setObjectName("primary")
        create.clicked.connect(self.create_clone)
        lay.addWidget(create)
        self.clone_msg = QLabel("")
        self.clone_msg.setObjectName("muted")
        self.clone_msg.setWordWrap(True)
        lay.addWidget(self.clone_msg)
        lay.addWidget(QLabel("Existing clones:"))
        self.clone_list = QListWidget()
        lay.addWidget(self.clone_list)
        drow = QHBoxLayout()
        refresh = QPushButton("Refresh")
        refresh.clicked.connect(self.refresh_clones)
        delete = QPushButton("Delete selected")
        delete.setObjectName("danger")
        delete.clicked.connect(self.delete_clone)
        drow.addWidget(refresh)
        drow.addWidget(delete)
        drow.addStretch(1)
        lay.addLayout(drow)
        self.refresh_clones()
        return w

    def pick_sample(self):
        p, _ = QFileDialog.getOpenFileName(
            self, "Voice sample", "",
            "Audio (*.mp3 *.wav *.m4a *.ogg *.flac)")
        if p:
            self.clone_sample.setText(p)

    def _key_or_warn(self):
        key = self.ai33_key.text().strip() if hasattr(self, "ai33_key") \
            else self.secrets.get("ai33pro_api_key", "").strip()
        if not key:
            QMessageBox.warning(self, "AI33 Pro",
                                "Paste the AI33 Pro key on the Voiceover tab first. "
                                "The sample stays selected until then.")
        return key

    def create_clone(self):
        key = self._key_or_warn()
        if not key:
            return
        sample = self.clone_sample.text().strip()
        name = self.clone_name.text().strip()
        if not sample or not Path(sample).is_file():
            QMessageBox.warning(self, "Clone", "Choose a sample audio file first.")
            return
        try:
            vid = ai33voice.clone_voice(key, name or "My clone", sample)
        except ai33voice.AI33Error as e:
            self.clone_msg.setText(f"Clone failed: {e}")
            return
        # auto-lock to the channel's avatar
        cid = self.clone_channel.currentData()
        ch = (self.cfg.get("channels") or {}).get(cid) or {}
        ch["voice"] = {"provider": "ai33pro", "voice_id": vid,
                       "name": name or vid}
        save_config(self.cfg)
        self.clone_msg.setText(
            f"Cloned → {vid}. Locked to channel "
            f"'{ch.get('name', cid)}': every video for this channel now "
            f"uses this voice.")
        self.refresh_clones()

    def refresh_clones(self):
        self.clone_list.clear()
        key = self.secrets.get("ai33pro_api_key", "").strip()
        if not key and hasattr(self, "ai33_key"):
            key = self.ai33_key.text().strip()
        if not key:
            QListWidgetItem("(paste the AI33 Pro key to list clones)",
                            self.clone_list)
            return
        try:
            clones = ai33voice.list_clones(key)
        except ai33voice.AI33Error as e:
            QListWidgetItem(f"(could not list: {e})", self.clone_list)
            return
        if not clones:
            QListWidgetItem("(no cloned voices yet)", self.clone_list)
        for v in clones:
            QListWidgetItem(f"{v['name']}  <{v['id']}>", self.clone_list)

    def delete_clone(self):
        item = self.clone_list.currentItem()
        if not item or "<" not in item.text():
            return
        vid = item.text().split("<")[-1].rstrip(">")
        key = self.secrets.get("ai33pro_api_key", "").strip()
        if hasattr(self, "ai33_key") and self.ai33_key.text().strip():
            key = self.ai33_key.text().strip()
        try:
            ai33voice.delete_clone(key, vid)
        except ai33voice.AI33Error as e:
            QMessageBox.warning(self, "Delete clone", str(e))
            return
        # unlock channels that used it
        for ch in (self.cfg.get("channels") or {}).values():
            v = ch.get("voice") or {}
            if v.get("voice_id") == vid:
                ch["voice"] = {"provider": "edge",
                               "voice_id": "en-US-AvaNeural"}
        save_config(self.cfg)
        self.refresh_clones()

    # ------------------------------------------------ images
    def _images_tab(self):
        w = QWidget()
        lay = QVBoxLayout(w)
        lay.addWidget(QLabel("Own AI images instead of paid stock footage. "
                             "Order tried: Grok → Gemini → free local."))
        # gemini
        lay.addWidget(QLabel("Google AI (Gemini) — same model family as Google Flow"))
        grow = QHBoxLayout()
        self.gem_key = QLineEdit()
        self.gem_key.setEchoMode(QLineEdit.Password)
        self.gem_key.setText(self.secrets.get("gemini_api_key", ""))
        self.gem_model = QComboBox()
        self.gem_model.setEditable(True)
        self.gem_model.addItems(["gemini-2.5-flash-image",
                                 "gemini-2.0-flash-preview-image-generation"])
        self.gem_model.setCurrentText(
            (self.cfg.get("providers") or {}).get("gemini_model",
                                                  "gemini-2.5-flash-image"))
        gtest = QPushButton("Test")
        gtest.clicked.connect(self.test_gemini)
        grow.addWidget(QLabel("Key:"))
        grow.addWidget(self.gem_key, 1)
        grow.addWidget(QLabel("Model:"))
        grow.addWidget(self.gem_model)
        grow.addWidget(gtest)
        lay.addLayout(grow)
        self.gem_msg = QLabel("")
        self.gem_msg.setObjectName("muted")
        lay.addWidget(self.gem_msg)
        # grok
        lay.addWidget(QLabel("Grok (xAI)"))
        xrow = QHBoxLayout()
        self.grok_key = QLineEdit()
        self.grok_key.setEchoMode(QLineEdit.Password)
        self.grok_key.setText(self.secrets.get("xai_api_key", ""))
        self.grok_model = QComboBox()
        self.grok_model.setEditable(True)
        self.grok_model.addItems(["grok-imagine-image", "grok-2-image"])
        self.grok_model.setCurrentText(
            (self.cfg.get("providers") or {}).get("grok_model",
                                                  "grok-imagine-image"))
        xtest = QPushButton("Test")
        xtest.clicked.connect(self.test_grok)
        xrow.addWidget(QLabel("Key:"))
        xrow.addWidget(self.grok_key, 1)
        xrow.addWidget(QLabel("Model:"))
        xrow.addWidget(self.grok_model)
        xrow.addWidget(xtest)
        lay.addLayout(xrow)
        self.grok_msg = QLabel("")
        self.grok_msg.setObjectName("muted")
        lay.addWidget(self.grok_msg)
        lay.addStretch(1)
        return w

    def test_gemini(self):
        import requests
        key = self.gem_key.text().strip()
        if not key:
            self.gem_msg.setText("Paste a key first.")
            return
        try:
            r = requests.post(
                "https://generativelanguage.googleapis.com/v1beta/models/"
                f"{self.gem_model.currentText()}:generateContent",
                headers={"x-goog-api-key": key},
                json={"contents": [{"parts": [{"text": "Reply with: OK"}]}]},
                timeout=30)
            if r.status_code == 200:
                self.gem_msg.setText("OK — Gemini key works.")
            else:
                self.gem_msg.setText(f"HTTP {r.status_code}: {r.text[:160]}")
        except Exception as e:  # noqa: BLE001
            self.gem_msg.setText(f"Failed: {e}"[:200])

    def test_grok(self):
        import requests
        key = self.grok_key.text().strip()
        if not key:
            self.grok_msg.setText("Paste a key first.")
            return
        try:
            r = requests.get("https://api.x.ai/v1/models",
                             headers={"Authorization": f"Bearer {key}"},
                             timeout=30)
            if r.status_code == 200:
                self.grok_msg.setText("OK — xAI key works.")
            else:
                self.grok_msg.setText(f"HTTP {r.status_code}: {r.text[:160]}")
        except Exception as e:  # noqa: BLE001
            self.grok_msg.setText(f"Failed: {e}"[:200])

    # ------------------------------------------------ channels
    def _channels_tab(self):
        w = QWidget()
        lay = QVBoxLayout(w)
        lay.addWidget(QLabel("One-time voice & presenter select per channel"))
        form = QFormLayout()
        self.ch_pick = QComboBox()
        for cid, ch in (self.cfg.get("channels") or {}).items():
            self.ch_pick.addItem(ch.get("name", cid), cid)
        self.ch_pick.currentIndexChanged.connect(self.load_channel)
        self.ch_voice_provider = QComboBox()
        self.ch_voice_provider.addItems(["edge", "ai33pro"])
        self.ch_voice_id = QLineEdit()
        browse = QPushButton("Browse voices…")
        browse.clicked.connect(self.browse_for_channel)
        vrow = QHBoxLayout()
        vrow.addWidget(self.ch_voice_id, 1)
        vrow.addWidget(browse)
        self.ch_presenter = QComboBox()
        for p in self.cfg.get("presenters") or []:
            self.ch_presenter.addItem(p.get("name", p.get("id")),
                                      p.get("id"))
        self.ch_minutes = QSpinBox()
        self.ch_minutes.setRange(1, 120)
        self.ch_subs = QCheckBox("Burn subtitles into the video (default OFF)")
        form.addRow("Channel:", self.ch_pick)
        form.addRow("Voice provider:", self.ch_voice_provider)
        form.addRow("Voice id:", vrow)
        form.addRow("Presenter:", self.ch_presenter)
        form.addRow("Default minutes:", self.ch_minutes)
        form.addRow("", self.ch_subs)
        lay.addLayout(form)
        apply = QPushButton("Apply to channel")
        apply.setObjectName("primary")
        apply.clicked.connect(self.apply_channel)
        lay.addWidget(apply)
        self.ch_msg = QLabel("")
        self.ch_msg.setObjectName("muted")
        lay.addWidget(self.ch_msg)
        lay.addStretch(1)
        self.load_channel()
        return w

    def load_channel(self):
        cid = self.ch_pick.currentData()
        ch = (self.cfg.get("channels") or {}).get(cid) or {}
        v = ch.get("voice") or {}
        self.ch_voice_provider.setCurrentText(v.get("provider", "edge"))
        self.ch_voice_id.setText(v.get("voice_id", ""))
        idx = self.ch_presenter.findData(ch.get("presenter"))
        if idx >= 0:
            self.ch_presenter.setCurrentIndex(idx)
        self.ch_minutes.setValue(int(ch.get("default_minutes", 5)))
        self.ch_subs.setChecked(bool(ch.get("subtitles")))

    def browse_for_channel(self):
        dlg = VoicePickerDialog(self, self.cfg, self.secrets)
        if dlg.exec() == QDialog.Accepted and dlg.result:
            provider, vid, _name = dlg.result
            self.ch_voice_provider.setCurrentText(provider)
            self.ch_voice_id.setText(vid)

    def apply_channel(self):
        cid = self.ch_pick.currentData()
        ch = (self.cfg.get("channels") or {}).get(cid) or {}
        ch["voice"] = {"provider": self.ch_voice_provider.currentText(),
                       "voice_id": self.ch_voice_id.text().strip()}
        ch["presenter"] = self.ch_presenter.currentData()
        ch["default_minutes"] = self.ch_minutes.value()
        ch["subtitles"] = self.ch_subs.isChecked()
        save_config(self.cfg)
        self.ch_msg.setText(
            f"Saved — every '{ch.get('name', cid)}' video now uses this voice.")

    # ------------------------------------------------ save
    def save(self):
        self.secrets["ai33pro_api_key"] = self.ai33_key.text().strip()
        self.secrets["gemini_api_key"] = self.gem_key.text().strip()
        self.secrets["xai_api_key"] = self.grok_key.text().strip()
        provs = self.cfg.setdefault("providers", {})
        provs["gemini_model"] = self.gem_model.currentText().strip()
        provs["grok_model"] = self.grok_model.currentText().strip()
        provs["script_provider"] = self.script_provider.currentText()
        provs["ai33pro_llm_base_url"] = self.llm_base.text().strip()
        provs["ai33pro_llm_model"] = self.llm_model.text().strip()
        save_secrets(self.secrets)
        save_config(self.cfg)
        self.accept()
