"""mib/ui/titles_dialog.py — viral title generator dialog.

"Generate 20 viral titles" (wizard Title step): sends the user's title
prompt to the script-LLM key pool (gemini / ai33pro, per Settings ->
Script -> Provider), parses the ranked titles, and lets the user tick
titles into the normal batch flow.

No key configured -> shows the copy-paste fallback dialog with the
ready prompt text (free/local fallback, same pattern as the
"prompt file only" thumbnail behaviour).
"""
from PySide6.QtCore import Qt, QThread, Signal
from PySide6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QTextEdit,
    QListWidget, QListWidgetItem, QApplication,
)

from ..prompts import viral_titles as _vt


class PromptCopyDialog(QDialog):
    """Free/local fallback: show the prompt text for copy-paste."""

    def __init__(self, parent, title, prompt_text, hint=""):
        super().__init__(parent)
        self.setWindowTitle(title)
        self.resize(600, 480)
        lay = QVBoxLayout(self)
        info = QLabel(
            "No script-LLM key is configured, so the app cannot call the "
            "AI for you. Copy the prompt below into any chatbot "
            "(ChatGPT, Gemini, Claude) and paste the 20 titles back into "
            "the title box." + (f" {hint}" if hint else ""))
        info.setWordWrap(True)
        lay.addWidget(info)
        self.box = QTextEdit()
        self.box.setReadOnly(True)
        self.box.setPlainText(prompt_text or "")
        lay.addWidget(self.box, 1)
        row = QHBoxLayout()
        row.addStretch(1)
        copy = QPushButton("Copy prompt")
        copy.clicked.connect(self._copy)
        close = QPushButton("Close")
        close.clicked.connect(self.reject)
        row.addWidget(copy)
        row.addWidget(close)
        lay.addLayout(row)
        self._copied = copy

    def _copy(self):
        try:
            QApplication.clipboard().setText(self.box.toPlainText())
            self._copied.setText("Copied ✓")
        except Exception:  # noqa: BLE001
            pass


class _TitlesWorker(QThread):
    """Generate titles in the background. Signals: done(dict)."""
    done = Signal(dict)

    def __init__(self, cfg, secrets, channel_id):
        super().__init__()
        self.cfg = cfg or {}
        self.secrets = secrets or {}
        self.channel_id = channel_id or ""

    def _call_llm(self, prompt):
        """Call the configured script-LLM pool. Raises on failure."""
        from ..config import CONFIG_PATH
        from ..keypool import pool_from_secrets
        provs = (self.cfg.get("providers") or {})
        provider = provs.get("script_provider") or "local"
        if provider == "gemini":
            from ..providers import geminillm
            pool = pool_from_secrets(
                "gemini-image", self.secrets,
                "gemini_api_key", "gemini_api_keys", CONFIG_PATH.parent)
            if pool is None:
                raise _vt.NoKeyError(prompt)
            return pool.run(
                lambda k: geminillm.generate_text(
                    prompt, k, provs.get("gemini_llm_model", "")),
                None, op="titles")
        if provider == "ai33pro":
            from ..providers import scriptllm
            pool = pool_from_secrets(
                "ai33-voice", self.secrets,
                "ai33pro_api_key", "ai33pro_api_keys", CONFIG_PATH.parent)
            if pool is None:
                raise _vt.NoKeyError(prompt)
            return pool.run(
                lambda k: scriptllm.generate_text(
                    prompt, k, provs.get("ai33pro_llm_base_url", ""),
                    provs.get("ai33pro_llm_model", "")),
                None, op="titles")
        raise _vt.NoKeyError(prompt)

    def run(self):  # noqa: D102
        try:
            ch = (self.cfg.get("channels") or {}).get(self.channel_id) or {}
            titles, _raw = _vt.generate(
                self._call_llm, ch.get("name", ""), ch.get("niche", ""))
            self.done.emit({"ok": True, "titles": titles})
        except _vt.NoKeyError as e:
            self.done.emit({"ok": False, "no_key": True,
                            "prompt": getattr(e, "prompt_text", "") or ""})
        except Exception as e:  # noqa: BLE001
            self.done.emit({"ok": False, "error": str(e)[:300]})


class TitlesDialog(QDialog):
    """Generate 20 viral titles -> tick -> into the batch."""

    def __init__(self, parent, cfg, secrets, channel_id):
        super().__init__(parent)
        self.cfg = cfg or {}
        self.secrets = secrets or {}
        self.channel_id = channel_id or ""
        self.setWindowTitle("Generate 20 viral titles")
        self.resize(620, 560)
        self.chosen_titles = []

        lay = QVBoxLayout(self)
        lay.addWidget(QLabel("<b>✨ 20 viral titles</b>"))
        info = QLabel(
            "Generates 20 original title ideas with the script LLM "
            "(Settings → Script → Provider), ranked strongest-first. "
            "Tick the ones you want, then add them to the batch.")
        info.setWordWrap(True)
        lay.addWidget(info)

        self.status = QLabel("Generating…")
        lay.addWidget(self.status)

        self.list = QListWidget()
        lay.addWidget(self.list, 1)

        row = QHBoxLayout()
        row.addStretch(1)
        close = QPushButton("Close")
        close.clicked.connect(self.reject)
        add = QPushButton("Add selected to batch")
        add.setObjectName("primary")
        add.clicked.connect(self._add_selected)
        row.addWidget(close)
        row.addWidget(add)
        lay.addLayout(row)

        self._worker = None

    def start(self):
        """Begin generation (called right after exec setup)."""
        self._worker = _TitlesWorker(self.cfg, self.secrets,
                                     self.channel_id)
        self._worker.done.connect(self._on_done)
        self._worker.start()

    def _on_done(self, res):
        if not res.get("ok"):
            if res.get("no_key"):
                self.reject()
                PromptCopyDialog(
                    self.parent(), "Copy the title prompt",
                    res.get("prompt") or _vt.build_prompt(),
                    "Then run 'Generate 20 viral titles' again, or paste "
                    "the titles straight into the title box.").exec()
            else:
                self.status.setText(f"⚠ {res.get('error') or 'failed'}")
            return
        titles = res.get("titles") or []
        self.list.clear()
        for i, t in enumerate(titles):
            it = QListWidgetItem(f"{i + 1}. {t}")
            it.setFlags(it.flags() | Qt.ItemIsUserCheckable)
            it.setCheckState(Qt.Checked if i < 3 else Qt.Unchecked)
            it.setData(Qt.UserRole, t)
            self.list.addItem(it)
        self.status.setText(
            f"{len(titles)} titles — strongest first. Top 3 pre-ticked; "
            "adjust, then 'Add selected'.")

    def _add_selected(self):
        chosen = [self.list.item(i).data(Qt.UserRole)
                  for i in range(self.list.count())
                  if self.list.item(i).checkState() == Qt.Checked]
        if not chosen:
            self.status.setText("Tick at least one title first.")
            return
        self.chosen_titles = chosen
        self.accept()
