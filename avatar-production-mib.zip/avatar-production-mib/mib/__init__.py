"""Avatar Production by MIB — fresh PySide6 desktop wizard app.

Mode -> Channel -> Presenter -> Title -> finished video.
Frontier dark+gold theme. Free local pipeline by default; paid providers
(AI33 Pro voice, Gemini/Grok images) are optional opt-ins in Settings.
"""
